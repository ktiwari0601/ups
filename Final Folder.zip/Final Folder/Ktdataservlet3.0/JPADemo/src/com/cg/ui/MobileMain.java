package com.cg.ui;
import java.util.Scanner;

import javax.persistence.*;

import com.cg.utilities.Mobile;

public class MobileMain 
{
 public static void main(String[] args)
 {
	 EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
	 EntityManager em=emf.createEntityManager();
	 Scanner sc=new Scanner(System.in);
	 
	 Mobile mob=new Mobile();
	 System.out.println("Enter Mobile name: ");
	 mob.setName(sc.next());
	 System.out.println("Enter price: ");
	 mob.setPrice(sc.nextFloat());
	 System.out.println("Enter Quantity: ");
	 mob.setQuantity(sc.next());
	 
	 em.getTransaction().begin();
	 em.persist(mob);
	 em.getTransaction().commit();
	 
	 System.out.println("Mobile Details Inserted");
	 sc.close();
 }
}
