package com.cg.utilities;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="mob")
@NamedQueries(@NamedQuery(name="getMobiles", query="SELECT m FROM Mobile WHERE m.quantity>:qty"))
public class Mobile 
{
   @Id
   @SequenceGenerator(name="myseq", sequenceName="seq_mob",allocationSize=1)
   @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="myseq")
	
	private int mobid;
	private String quantity;
	private String name;
	private float price;
	public int getMobId() {
		return mobid;
	}
	public void setMobId(int mobId) {
		this.mobid = mobId;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Mobile [mobId=" + mobid + ", quantity=" + quantity + ", name="
				+ name + ", price=" + price + "]";
	}
	public Mobile() {
		super();
	}

}
