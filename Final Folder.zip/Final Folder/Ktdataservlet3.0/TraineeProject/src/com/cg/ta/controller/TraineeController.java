package com.cg.ta.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.ta.entities.Trainee;
import com.cg.ta.service.TraineeService;

@Controller
public class TraineeController 
{
    static Integer SHOW_PAR_VIEW=1;
    static Integer SHOW_FULL_VIEW=2;
	@Autowired
	TraineeService tser;

	@RequestMapping("start")
	public String showhome(@RequestParam("username") String username,@RequestParam("password") String password, Model model)
	{

		if(username.equals("K") && password.equals("T"))
		{
			return "select";
		}
		else
		{
		 return "login";
		}
		
	}
	@RequestMapping ("add")
	public String addtrainee(@Valid@ModelAttribute("tDetails") Trainee tDetails, BindingResult res, Model model)
	{
		model.addAttribute("tDetails", tDetails);
		return "addtrainee";
	}
	@RequestMapping("addtrainee")
	public String addTraineePage(@Valid @ModelAttribute("tDetails") Trainee tDetails, BindingResult res, Model model)
	{
		if(res.hasErrors())
		{
			model.addAttribute("tDetails", tDetails);
			return "addtrainee";
		}
		else
		{
			tser.addTrainee(tDetails);
			model.addAttribute("tDetails",tDetails);
			return "select";
		}
		
	}
	
	@RequestMapping ("delete")
	public String deleteTrainee(@ModelAttribute("tDetails")Trainee tDetails, Model model)
	{
		model.addAttribute("tDetails",tDetails);
		model.addAttribute("view_mode", SHOW_PAR_VIEW);
		return "deletetrainee";
	}
	
    @RequestMapping ("deletetrainee")
    public String deletetraineeNow(@ModelAttribute("traineeId")Integer traineeId, Model model)
    {
    	model.addAttribute("traineeId", traineeId);
    	Trainee tDetails=tser.retrieveTrainee(traineeId);
    	model.addAttribute("tDetails",tDetails);
    	model.addAttribute("view_mode", SHOW_FULL_VIEW);
    	return "deletetrainee";
    }
	@RequestMapping("deleteNow")
	public String deletetraineeNow(@ModelAttribute("tDetails")Trainee tDetails, Model model)
	{
		model.addAttribute("tDetails", tDetails);
		tser.deleteTrainee(tDetails.getTraineeId());
		return "select";
	}
	@RequestMapping ("retrieve")
	public String showTrainee(@ModelAttribute("tDetails")Trainee tDetails, Model model)
	{
		model.addAttribute("view_mode", SHOW_PAR_VIEW);
		model.addAttribute("tDetails",tDetails);
		return "retrievetrainee";
	}
	@RequestMapping("retrievetrainee")
	public String retrieveTrainee(@ModelAttribute("tDetails")Trainee tDetails, Model model)
	{
		Trainee tDetails1=tser.retrieveTrainee(tDetails.getTraineeId());
		model.addAttribute("tDetails1",tDetails1);
		model.addAttribute("view_mode", SHOW_FULL_VIEW);
		return "retrievetrainee";
	}
	@RequestMapping("retrieveAll")
	 public String showTraineeDetails(Model model)
	 {
		 List<Trainee> tlist=tser.fetchAll();
		 model.addAttribute("tlist",tlist);
		 return "retrievealltrainee";
	 }
	@RequestMapping("modify")
	 public String modifyTrainee(@ModelAttribute("tDetails")Trainee tDetails,Model model)
	 {
		model.addAttribute("tDetails",tDetails);
		model.addAttribute("view_mode",SHOW_PAR_VIEW);
		return "modifytrainee";
	 }
	@RequestMapping("modifytrainee")
	public String modifyTraineeDetails(@ModelAttribute("traineeId")Integer traineeId,Model model)
	 {
		 
		 Trainee tDetails=tser.retrieveTrainee(traineeId);
		 model.addAttribute("tDetails",tDetails);
		 model.addAttribute("view_mode",SHOW_FULL_VIEW);
		 return "modifytrainee";
	 }
	@RequestMapping("finalModify")
	public String finalModifyTrainee(@ModelAttribute("tDetails")Trainee tDetails,
			Model model)
	 {
		tser.modify(tDetails);
		return "select";
		
	 }
}
