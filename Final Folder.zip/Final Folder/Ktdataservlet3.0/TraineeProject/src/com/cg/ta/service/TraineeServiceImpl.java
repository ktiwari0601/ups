package com.cg.ta.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.ta.dao.TraineeDao;
import com.cg.ta.entities.Trainee;

@Service
@Transactional
public class TraineeServiceImpl implements TraineeService {

	@Autowired
	TraineeDao tdao;
	@Override
	public void addTrainee(Trainee tDetails) 
	{
		tdao.addTrainee(tDetails);
		
	}
	@Override
	public Trainee deleteTrainee(Integer traineeId) {
		return tdao.deleteTrainee(traineeId);
	    
	}
	@Override
	public Trainee retrieveTrainee(Integer traineeId) {
		return tdao.retrieveTrainee(traineeId);
	}
	@Override
	public List<Trainee> fetchAll() {
		return tdao.fetchAll();
	}
	@Override
	public void modify(Trainee tDetails) 
	{
		tdao.modify(tDetails);
		
	}

}
