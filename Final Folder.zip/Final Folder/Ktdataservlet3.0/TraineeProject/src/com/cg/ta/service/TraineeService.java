package com.cg.ta.service;

import java.util.List;

import com.cg.ta.entities.Trainee;

public interface TraineeService 
{

	void addTrainee(Trainee tDetails);
	Trainee deleteTrainee(Integer traineeId);
	Trainee retrieveTrainee(Integer traineeId);
	List<Trainee> fetchAll();
	void modify(Trainee tDetails);
}
