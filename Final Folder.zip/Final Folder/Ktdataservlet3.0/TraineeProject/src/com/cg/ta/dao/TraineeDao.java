package com.cg.ta.dao;

import java.util.List;

import com.cg.ta.entities.Trainee;

public interface TraineeDao 
{

	void addTrainee(Trainee tDetails);
    Trainee deleteTrainee(Integer traineeId);
	Trainee retrieveTrainee(Integer traineeId);
	List<Trainee> fetchAll();
	void modify(Trainee tDetails);
}
