package com.cg.ta.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import javax.persistence.PersistenceContext;

import com.cg.ta.entities.Trainee;

@Repository
public class TraineeDaoImpl implements TraineeDao
{
	@PersistenceContext
	private EntityManager em;

	@Override
	public void addTrainee(Trainee tDetails) 
	{
		em.persist(tDetails);	
		
	}

	@Override
	public Trainee deleteTrainee(Integer traineeId) 
	{
		String jpql="SELECT t from Trainee t WHERE traineeId=:trid";
		TypedQuery<Trainee> query= em.createQuery(jpql, Trainee.class);
		query.setParameter("trid", traineeId);
		Trainee traineeList=query.getSingleResult();
		em.remove(traineeList);
		return traineeList;
	}

	@Override
	public Trainee retrieveTrainee(Integer traineeId) 
	{
		String jpql="SELECT t from Trainee t WHERE traineeId=:trid";
		TypedQuery<Trainee> query= em.createQuery(jpql, Trainee.class);
		query.setParameter("trid", traineeId);
		Trainee traineeList=query.getSingleResult();
		return traineeList;
	}

	@Override
	public List<Trainee> fetchAll() {
		String jpql="SELECT t from Trainee t";
		TypedQuery<Trainee> query= em.createQuery(jpql, Trainee.class);
		return query.getResultList();
		
	}

	@Override
	public void modify(Trainee tDetails)
	{
		em.merge(tDetails);	
	}
}
