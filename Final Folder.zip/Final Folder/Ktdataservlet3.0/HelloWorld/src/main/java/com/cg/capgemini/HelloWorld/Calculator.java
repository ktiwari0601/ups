package com.cg.capgemini.HelloWorld;

public class Calculator 
{

	public int sub(int i, int j) {
		
		return (i-j);
	}

	public int add(int i, int j) {
		// TODO Auto-generated method stub
		return (i+j);
	}
 
}
