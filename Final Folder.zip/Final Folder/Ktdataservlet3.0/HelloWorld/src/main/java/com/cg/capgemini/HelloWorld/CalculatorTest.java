package com.cg.capgemini.HelloWorld;

import org.junit.Assert;

public class CalculatorTest 
{
	public void testAdd()
	{
	  Calculator calc=new Calculator();
      int res=calc.add(4,6);
       Assert.assertEquals(10, res);
	}
	public void testSub()
	{
	 Calculator calc=new Calculator();
     int res=calc.sub(4,6);
     Assert.assertEquals(, res);
	}
 }
