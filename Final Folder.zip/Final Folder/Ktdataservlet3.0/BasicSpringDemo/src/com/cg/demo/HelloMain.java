package com.cg.demo;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

public class HelloMain 
{

	public static void main(String[] args)
	{
	 XmlBeanFactory factory=new XmlBeanFactory(new ClassPathResource("demo.xml"));	
	 HelloBean bean= (HelloBean) factory.getBean("hBean");
	 System.out.println(bean.helloWorld());
	 
	 //Address myAdd = (Address)factory.getBean("address");
	 //System.out.println(myAdd);
	
	 Employee emp = factory.getBean(Employee.class);
	 System.out.println(emp);
	}
}
