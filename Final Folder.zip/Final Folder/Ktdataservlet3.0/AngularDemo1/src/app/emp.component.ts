import { Component } from '@angular/core';

@Component({
    selector: 'my-emp',
    template: `<h2>{{empno}}</h2>
    <h2>{{empName}}</h2><h2>{{sal}}</h2>`;
 })
 export class Employee{
      empno:number=0007;
      empName:string="KT";
      sal:number=9999;
 }  