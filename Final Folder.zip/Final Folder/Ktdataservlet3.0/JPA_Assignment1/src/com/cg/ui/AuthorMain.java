package com.cg.ui;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.utilities.Author;

public class AuthorMain
{

	public static void main(String[] args)
	 {
		 int choice;
		 EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		 EntityManager em=emf.createEntityManager();
		 Scanner sc=new Scanner(System.in);
		System.out.println("Select Operation 1:Insert Author \n 2:Update Author \n 3:Delete Author \n 4:sssssssssssss")
		 
		 
		 Author auth=new Author();
		 System.out.println("Enter Author's First name: ");
		 auth.setfName(sc.next());
		 System.out.println("Enter Author's Middle name: ");
		 auth.setmName(sc.next());
		 System.out.println("Enter Author's Last name: ");
		 auth.setlName(sc.next());
		 System.out.println("Enter Phone No: ");
		 auth.setPhone(sc.nextInt());
		 
		 em.getTransaction().begin();
		 em.persist(auth);
		 em.getTransaction().commit();
		 
		 System.out.println("Author Details Inserted");
		 sc.close();
	 }
}
