package com.cg.utilities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

	@Entity
	@Table(name="auth")
     	public class Author 
	{
	   @Id
	   @SequenceGenerator(name="myseq", sequenceName="seq_auth",allocationSize=1)
	   @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="myseq")
		@Column(name="authorId")
		private int author_id;
	   @Column(name="firstName")
		private String fName;
	   @Column(name="middleName")
	   private String mName;
	   @Column(name="lastName")
		private String lName;
	   @Column(name="phoneNo")
	   private int phone;
		
		public int getAuthor_id() {
			return author_id;
		}
		public void setAuthor_id(int author_id) {
			this.author_id = author_id;
		}
		public String getfName() {
			return fName;
		}
		public void setfName(String fName) {
			this.fName = fName;
		}
		public String getmName() {
			return mName;
		}
		public void setmName(String mName) {
			this.mName = mName;
		}
		public String getlName() {
			return lName;
		}
		public void setlName(String lName) {
			this.lName = lName;
		}
		public int getPhone() {
			return phone;
		}
		public void setPhone(int phone) {
			this.phone = phone;
		}
		@Override
		public String toString() {
			return "Author [author_id=" + author_id + ", fName=" + fName
					+ ", mName=" + mName + ", lName=" + lName + ", phone="
					+ phone + "]";
		}
		public Author() {
			super();
		}
		public Author(int author_id, String fName, String mName, String lName,
				int phone) {
			super();
			this.author_id = author_id;
			this.fName = fName;
			this.mName = mName;
			this.lName = lName;
			this.phone = phone;
		}
	}