package com.cg.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.fie.entities.Client;
import com.cg.fie.service.IQueryService;


@Controller
public class QueryController
{
	@Autowired
	IQueryService qser;                                          //Service class object       
	
	@RequestMapping("start")                                     //Mapping from index page to 'home' page(Enter Query)
	public String showhome(@ModelAttribute("qDetails")Client qDetails,Model model)
	{
		model.addAttribute("qDetails",qDetails);
		return "home";
	}
	

	@RequestMapping("retrieve")
	public String retrieveQuery(@Valid @ModelAttribute("qDetails")Client qDetails,BindingResult res, Model model)
	{
		if(res.hasErrors())                                                  //If Error is encountered during Retrieval, redirects to  error display page
		{
			model.addAttribute("qDetails", qDetails);
			return "querynotfound";
		}
		else
		   {                                                                                       
			 Client qDetails1=qser.retrieveQuery(qDetails.getQuery_id());    //If no error is encountered, displays the query details by calling page retrievequery.jsp                        
			 model.addAttribute("qDetails1",qDetails1);
			 return "retrievequery";
	
			}
		}
	
	
	
}
