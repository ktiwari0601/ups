package com.cg.fie.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.fie.dao.IQueryDao;
import com.cg.fie.entities.Client;

@Service
@Transactional
//Service Layer Implementation
public class QueryServiceImpl implements IQueryService 
{
 
	@Autowired                                                   //Autowiring provided
	IQueryDao qdao;                                              //Object of Data Access Layer Interface
	
	@Override
	public Client retrieveQuery(Integer query_id)                  
	{
	    return qdao.retrieveQuery(query_id);                     //Function of DAO called       
	}
 
}
