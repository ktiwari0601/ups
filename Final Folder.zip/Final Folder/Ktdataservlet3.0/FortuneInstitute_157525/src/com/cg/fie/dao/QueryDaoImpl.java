package com.cg.fie.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.fie.entities.Client;

@Repository
public class QueryDaoImpl implements IQueryDao      //Implementation Class of DAO Interface
{

	@PersistenceContext
	private EntityManager em;                       //JPA Object              

	@Override
	public Client retrieveQuery(Integer queryid)    //Function to Find and Return queried id by accessing database 'query_master'
	{
		String jpql="SELECT q from Client q WHERE query_id=:qid";      //Query for searching query id           
		TypedQuery<Client> query= em.createQuery(jpql, Client.class);
		query.setParameter("qid", queryid);
		Client clientList=query.getSingleResult();
		return clientList;
		
	}
 
}
