package com.cg.fie.dao;

import com.cg.fie.entities.Client;

public interface IQueryDao                                                      //Function declared for accessing table 
{
   Client retrieveQuery(Integer query_id);
}
