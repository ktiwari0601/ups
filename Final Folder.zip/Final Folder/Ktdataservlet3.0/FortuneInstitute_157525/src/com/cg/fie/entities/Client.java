package com.cg.fie.entities;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@Entity
@Table(name="query_master")
public class Client                              //Java Class of query_master
{

	
		@Id
		@NotNull(message="Query Id should NOT be blank and value cannot be <1")      
		@Pattern(regexp="[1-9]{1,9}",message="Query Id should be a Number")             //Validation of Query Id by Regular Expression
		private Integer query_id;                                                     //Variable of Query id
		private String technology;                                                    //Variable of Technology 
		private String query_raised_by;                                               //Variable of Name of Query Raiser
		private String query;                                                         //Variable of Query
		
		//Getter and Setter Functions
		public Integer getQuery_id() {
			return query_id;
		}
		public void setQuery_id(Integer query_id) {
			this.query_id = query_id;
		}
		public String getTechnology() {
			return technology;
		}
		public void setTechnology(String technology) {
			this.technology = technology;
		}
		public String getQuery_raised_by() {
			return query_raised_by;
		}
		public void setQuery_raised_by(String query_raised_by) {
			this.query_raised_by = query_raised_by;
		}
		public String getQuery() {
			return query;
		}
		public void setQuery(String query) {
			this.query = query;
		}
		@Override
		public String toString() {
			return "Client [query_id=" + query_id + ", technology="
					+ technology + ", query_raised_by=" + query_raised_by
					+ ", query=" + query + "]";
		}
		//Parameterised Constructor
		public Client(Integer query_id, String technology,
				String query_raised_by, String query) {
			super();
			this.query_id = query_id;
			this.technology = technology;
			this.query_raised_by = query_raised_by;
			this.query = query;
		}
		//default constructor
		public Client() {
			super();
		}
		
		
}
