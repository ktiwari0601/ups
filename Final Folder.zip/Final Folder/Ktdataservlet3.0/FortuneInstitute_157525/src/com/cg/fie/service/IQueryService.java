package com.cg.fie.service;

import com.cg.fie.entities.Client;

public interface IQueryService                                    //Function declaration in Service layer Interface
{

	Client retrieveQuery(Integer query_id);
}
