

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class HiddenFormFieldServlet
 */
@WebServlet("/HiddenFormFieldServlet")
public class HiddenFormFieldServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HiddenFormFieldServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String uname=request.getParameter("username");
		String pwd=request.getParameter("password");
		PrintWriter out=response.getWriter();
		out.println("<html><body>");
		out.println("<h1>Welcome "+uname);
		out.println("<form action='PaymentServlet'method='post'>");
	    out.println("Select method from list below:");
	    out.println("<br> <input type='radio' name='product' value='TV'>Sony Bravia </input>");
	    out.println("<br> <input type='radio' name='product' value='mobiles'>Mobile </input>");
        out.println("<br> <input type='radio' name='product' value='ipad'>IPad </input>");
        out.println("<br> <input type='hidden' name='username' value="+uname);
        out.println("<br> <input type='hidden' name='password' value="+pwd);
        out.println("</form>");
        out.println("</body>");
        out.println("</html>");
	}

}
