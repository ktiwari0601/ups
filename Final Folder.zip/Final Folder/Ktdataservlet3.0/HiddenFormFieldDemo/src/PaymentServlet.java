

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class PaymentServlet
 */
@WebServlet("/PaymentServlet")
public class PaymentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PaymentServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username= request.getParameter("username");
		String product= request.getParameter("product");
		PrintWriter out=response.getWriter();
		
		out.println("<html><body>");
		out.println("Hello "+username);
		out.println("<br>You Selected..."+product);
		out.println("<br>Select Payment Option from list below");
		out.println("<form>");
		out.println("<br> <input type='radio' name='payment' value='card'> card </input>");
		out.println("<br> <input type='radio' name='product' value='netbanking'> netbanking </input>");
		out.println("<br> <input type='radio' name='product' value='paytm'> paytm </input>"); 
		out.println("<br> <input type='sumbit' name='pay' value='click to pay'>");
		out.println("</form>");
		out.println("</body></html>");
		
	}

}
