

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Firstservdemo
 */
@WebServlet("/Payments")
public class Firstservdemo extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Firstservdemo() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	  PrintWriter out=response.getWriter();
	  out.println("<h2>Welcome To Servelet </h2>");
	  out.println("<h1>Request Sent using HTTP get method</h1>");
	  String query= request.getQueryString();
	  out.println(query);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		String username=request.getParameter("userNameTxt");
		String pwd=request.getParameter("pass123");
		if(username.equals("capgemini") && pwd.equals("corp123"))
		{
			out.println("Welcome User");
		}
		else
		{
			 out.println("<H2 style='color:red;'>Invalid user/Password</H2>");
		}
	}

}
