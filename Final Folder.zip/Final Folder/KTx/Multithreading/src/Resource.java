public class Resource {
private int data;
boolean dataAvailable=false;
synchronized void insert(int data) 
{
if(dataAvailable){
 try {
	 wait();
 }
 catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
 
}
else {
	this.data=data;
	dataAvailable=true;
	notify();
}}
synchronized int retrieve()
{
    if(!dataAvailable) {
    	try {
			wait();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
     
    
        dataAvailable=false;
    	notify();
        return this.data;	
    
	
}
	
}
