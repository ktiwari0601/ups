package com.example.RailwayReservation;

import java.util.Date;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;

//*****************Controller to Handle Requests & Mappings**************//
@RestController
public class ReservationController 
{
	@Autowired
    ReservationService reservationS;
	
	//***********Method to Insert Reservation Details***************//
	@PostMapping(value="/insert")
	public String insert(@RequestBody Client rDet)
	{
		reservationS.save(rDet);
		return "Insertion Successfull";
	}
	
	//***********Method to Find PNR***************//
	@GetMapping("/user/{pnrno}")
	public Optional <Client> findId(@PathVariable("pnrno")String pnrno) throws ReservationException
	{	if(reservationS.existsById(pnrno))
		{
		return reservationS.findById(pnrno);
	}
	else{
		throw new ReservationException("PNR Not Found wrong PnrNo : "+pnrno);
	}
		
	}
	//***********Method to Handle Exceptions***************//
	@ExceptionHandler(ReservationException.class)
	    public ResponseEntity<ErrorResponse> exceptionHandler(Exception ex, WebRequest request) {
	      ErrorResponse errorDetails = new ErrorResponse(new Date(), ex.getMessage(), request.getDescription(false));
	        return new ResponseEntity<ErrorResponse>(errorDetails, HttpStatus.OK);
	
	    }

}