package com.example.RailwayReservation;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface ReservationService extends MongoRepository<Client, String>{

}
