package com.example.RailwayReservation;

//***********User Defined Exception CLass***************//
public class ReservationException extends Exception {
	private static final long serialVersionUID = 1L;
	private String errorMessage;
 
	public String getErrorMessage() {
		return errorMessage;
	}
	public ReservationException(String errorMessage) {
		super(errorMessage);
		this.errorMessage = errorMessage;
	}
	public ReservationException() {
		super();
	}
}