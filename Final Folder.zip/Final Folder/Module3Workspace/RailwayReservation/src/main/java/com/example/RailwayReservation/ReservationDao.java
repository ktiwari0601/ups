package com.example.RailwayReservation;

public interface ReservationDao {

}
