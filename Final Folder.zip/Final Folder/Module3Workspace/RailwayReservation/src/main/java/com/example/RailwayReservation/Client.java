package com.example.RailwayReservation;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

//***********Object Class***************//

@Document(collection="Reservation")
public class Client 
{
 @Id
 String pnrno;
 String name;
 String source_loc;
 String desc_loc;
 int price;
public Client() {
	super();
}
public Client(String pnrno, String name,
		String source_loc, String desc_loc, int price) {
	super();
	this.pnrno = pnrno;
	this.name = name;
	this.source_loc = source_loc;
	this.desc_loc = desc_loc;
	this.price = price;
}
public String getPnrno() {
	return pnrno;
}
public void setPnrno(String pnrno) {
	this.pnrno = pnrno;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getSource_loc() {
	return source_loc;
}
public void setSource_loc(String source_loc) {
	this.source_loc = source_loc;
}
public String getDesc_loc() {
	return desc_loc;
}
public void setDesc_loc(String desc_loc) {
	this.desc_loc = desc_loc;
}
public int getPrice() {
	return price;
}
public void setPrice(int price) {
	this.price = price;
}
}
