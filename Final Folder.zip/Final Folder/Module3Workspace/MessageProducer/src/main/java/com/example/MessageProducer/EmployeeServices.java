package com.example.MessageProducer;

//import java.io.IOException;
//import java.util.ArrayList;
//import javax.servlet.http.HttpServletResponse;
//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
//import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.PutMapping;
//import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/emp")
public class EmployeeServices 
{
	 //@Autowired
	 //EmployeeDAO employeeDao;
	 // ArrayList <Employee> arrEmp = new ArrayList<Employee>();
     //@RequestMapping(path="/select",method=RequestMethod.GET, produces=MediaType.APPLICATION_XML_VALUE)
	 
	 @GetMapping(value="/select/{id}", produces=MediaType.APPLICATION_XML_VALUE)
      public Employee readEmployee(@PathVariable("id")Long id)
	{
	     Employee emp = new Employee();
	     System.out.println(id);
		 return emp;
	}
	/*
	 @PostMapping(value="/insert", consumes=MediaType.APPLICATION_JSON_VALUE)
	public Employee insertEmployee(@RequestBody Employee emp)
	{
		employeeDao.save(emp);
		return emp;
	}
	
	 @PutMapping(value="/update/{id}/{sal}",produces=MediaType.APPLICATION_JSON_VALUE)
	 public Employee updateEmpSal(@PathVariable("id")Long id,@PathVariable("sal")int sal)
	{
		if(employeeDao.existsById(id))
		{
		 	Employee emp=employeeDao.findById(id).get();
		 	emp.setSalary(sal);
		 	employeeDao.save(emp);
			return emp;
		}
		else
		{
			System.out.println("Entry Not Found. Invalid Id!!!");
			return null;
		}
		
	}
	
	 @PutMapping(value="/update/{id}/age",produces=MediaType.APPLICATION_XML_VALUE)
	 public Employee updateEmpAge(@PathVariable("id")Long id,@PathVariable("age")int age)
	{
		if(employeeDao.existsById(id))
		{
		 	Employee emp=employeeDao.findById(id).get();
		 	emp.setAge(age);
		 	employeeDao.save(emp);
			return emp;
		}
		else
		{
			System.out.println("Entry Not Found. Invalid Id!!!");
		}
		return null;
	}
	
	
	 @GetMapping(value="/delete/{id}")
	  public String delEmployee(@PathVariable("id")Long id)
	{
	   if(employeeDao.existsById(id))
	   {
		 employeeDao.deleteById(id);
	     return "Entry Successfully Deleted!!!";
	   }
	   else
	   {
		   return "Entry NOT Found!!!";
	   }
	}

	@ExceptionHandler(Exception.class)
	public void handler(HttpServletResponse res)
	{
		 try
		 {
			 res.sendRedirect("http://google.com");
	     }
		 catch(IOException e)
		 {
		   e.printStackTrace();	 
		 }
	}
*/
}
