package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component(value="emp")
public class Employee 
{
	@Autowired
	@Qualifier("lADS")
	Address ads;
 public void display()
 {
	 	 System.out.println("City Of Employee :"+ ads.city());
	 	 
 }
 
}
