package com.example.TestMethod;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestMethodApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestMethodApplication.class, args);
	}
}
