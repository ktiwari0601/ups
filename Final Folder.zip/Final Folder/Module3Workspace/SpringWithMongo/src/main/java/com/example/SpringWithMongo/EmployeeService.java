package com.example.SpringWithMongo;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.Mapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmployeeService {

	@Autowired
	DBServices service;
	
	 //ArrayList <Employee> arrEmp = new ArrayList<Employee>();
	 //List <Employee> arrEmp = new List<Employee>(); 
	//****************************************
	@PostMapping(value="/insert")
	public String insert(@RequestBody Employee e)
	{
		service.save(e);
		return "Success";
	}
	//***************************************
	/*@PostMapping("/insertAll")
	public String insertAll(@RequestBody Employee e)
	{
	 	service.saveAll(arg0)
	}*/
	//***************************************
	@GetMapping("/getId/{idno}")
	public Optional<Employee> findId(@PathVariable("idno")Long idno)
	{
		return service.findById(idno);
	}
	//***************************************
	@GetMapping("/getAll")
	public List<Employee> getAll()
	{
		return service.findAll();
	}
	//***************************************
	
	@PutMapping("/update/{idno}")
	public String updateDet(@PathVariable("idno")Long idno,@RequestBody Employee e)
	{
		Optional <Employee> em=service.findById(idno);
		if(em.isPresent())
		{
		 service.save(e);
	  	 return e.getName()+" Updated Sucessfully";
	    }
	    return "Employee Not Found!";
	}
	//***********************************
	@DeleteMapping(value="/delete/{id}")
	public String deleteId(@PathVariable("idno")Long idno)
	{
		Optional <Employee> em=service.findById(idno);
		if(em.isPresent())
		{
		 service.deleteById(idno);
		 return "Deletion Successfull!";
	    }
		return "Employee Not Found!";
	}
	//***********************************
	@DeleteMapping(value="/deleteAll")
	public String delAll()
	{
		service.deleteAll();
		return "Deletion Successfull!";
	}
	//***********************************
}
