package com.example.SpringWithMongo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="MongoD")
public class Employee {

	@Id
	private int idno;
	private int age;
	public int getIdno() {
		return idno;
	}
	public void setIdno(int idno) {
		this.idno = idno;
	}
	private int salary;
	private String name;
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	public Employee(int idno, int age, int salary, String name) {
		super();
		this.idno = idno;
		this.age = age;
		this.salary = salary;
		this.name = name;
	}
	public Employee() {
		super();
	}
	
}
