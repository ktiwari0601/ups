package com.cg.mps.juint;

import java.util.ArrayList;

import org.junit.Test;

import com.cg.mps.dto.Mobile;
import com.cg.mps.dto.Purchase;
import com.cg.mps.exception.MobilePurchaseException;
import com.cg.mps.service.MobileService;
import com.cg.mps.service.MobileServiceImpl;
import com.cg.mps.service.PurchaseServiceImpl;
import com.cg.mps.ui.TestMPSClient;

import junit.framework.Assert;

public class TestOpeartions {
	
	@Test
	public void testfn1() throws MobilePurchaseException
	{
		Purchase obj=new Purchase("Sruti","sruti@gmail.com","8375875349",1001);
		PurchaseServiceImpl purService=new PurchaseServiceImpl();
		Assert.assertEquals(1,purService.addCust(obj));
		
	}
	
	@Test(expected=com.cg.mps.exception.MobilePurchaseException.class)
	public void testfn2() throws MobilePurchaseException
	{
		Purchase obj=new Purchase("Rishav","rishav@gmail.com","8375875349",4001);
		PurchaseServiceImpl purService=new PurchaseServiceImpl();
		purService.addCust(obj);
	}
	
	@Test
	public void testfn3() throws MobilePurchaseException
	{

		MobileService mService=new MobileServiceImpl();
		ArrayList<Mobile> mList = mService.search(2000,20000);
		Assert.assertEquals(false, mList.isEmpty());
		
	}
	
	@Test
	public void testfn4() throws MobilePurchaseException
	{

		MobileService mService=new MobileServiceImpl();
		ArrayList<Mobile> mList = mService.search(2000,200);
		Assert.assertEquals(true, mList.isEmpty());
		
	}
}
