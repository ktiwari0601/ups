package com.cg.mps.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.mps.dto.Mobile;
import com.cg.mps.dto.Purchase;
import com.cg.mps.exception.MobilePurchaseException;
import com.cg.mps.service.MobileService;
import com.cg.mps.service.MobileServiceImpl;
import com.cg.mps.service.PurchaseService;
import com.cg.mps.service.PurchaseServiceImpl;

public class TestMPSClient {
	static PurchaseService purService=null;
	static MobileService mService=null;
	static Scanner sc=null;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		sc=new Scanner(System.in);
		purService=new PurchaseServiceImpl();
		mService=new MobileServiceImpl();
		int choice=0;
		System.out.println("*********Welcome to MPS**********");
		while(true)
		{
			System.out.println("What do you want to do?");
			System.out.println("\t 1)add Employee \t 2)Show All Mobile Details \t 3)Search Mobile Details \t 4)Delete Mobile Details \t 5)Exit");
			System.out.println("Enter your choice:");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:insertCust();
			break;
			case 2:displayAllMobiles();
			break;
			case 3:searchMobile();
			break;
			case 4:deleteMobile();
			break;
			default:System.exit(0);
			}
		}
	}
	private static void deleteMobile() {
		// TODO Auto-generated method stub
		try {
		System.out.println("Enter the mobile id to be deleted:");
		int mid=sc.nextInt();
		int dataDeleted=mService.delete(mid);
		System.out.println("No of row deleted:"+dataDeleted);
		}
		catch (MobilePurchaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	private static void displayAllMobiles() {
		ArrayList<Mobile> mList;
		// TODO Auto-generated method stub
		try {
			mList=mService.display();
			System.out.println("\tMobileID \tMobileNAME \tMobilePrice \tMobileQuantity");
			for(Mobile m:mList)
			{
				System.out.println("\t"+m.getMobileId()+"\t\t"+m.getName()+"\t"+m.getPrice()+"\t"+m.getQuantity());
			}
		} catch (MobilePurchaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	private static void insertCust() {
		// TODO Auto-generated method stub
		try {
		//System.out.println("Enter your emp id:");
		//int eid=sc.nextInt();
		
		System.out.println("Enter your name:");
		String ename=sc.next();
		//try {
		purService.validateCustName(ename);
		//}
		//catch(Exception e)
		//{
			//throw new MobilePurchaseException("Maximum 20 characters allowed and start with capital letter only");
		//}
		System.out.println("Enter your contact number:");
		String pno=sc.next();
		purService.validatePhoneNo(pno);
		
		System.out.println("Enter the mobile id for purchase:");
		int mid=sc.nextInt();
		purService.validateMobileId(mid);
		System.out.println("Enter your mailid:");
		String mail=sc.next();
		purService.validateEmailId(mail);
			/*if(empService.validateEmpName(ename))
			{
				System.out.println("Enter your salary:");
				float esal=sc.nextFloat();*/
				Purchase obj=new Purchase(ename,mail,pno,mid);
				
				int dataInserted=purService.addCust(obj);
				if(dataInserted==0)
					//displayAllEmp();
				//else
					System.out.println("Sorry,data not inserted");
			//}
		
		}
		catch (MobilePurchaseException e) {
			//e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}
	private static void searchMobile() {
		// TODO Auto-generated method stub
		ArrayList<Mobile> mList;
		try 
		{
			
			System.out.println("Enter the minimum value of the range:");
			double min=sc.nextDouble();
			System.out.println("Enter the maximum value of the range:");
			double max=sc.nextDouble();
				
				mList=mService.search(min,max);;
				System.out.println("\tMobileID \tMobileNAME \tMobilePrice \tMobileQuantity");
				for(Mobile m:mList)
				{
					System.out.println("\t"+m.getMobileId()+"\t\t"+m.getName()+"\t"+m.getPrice()+"\t"+m.getQuantity());
				}
			//}
		
		}
		catch (MobilePurchaseException e) {
			e.printStackTrace();
		}
	}
}
