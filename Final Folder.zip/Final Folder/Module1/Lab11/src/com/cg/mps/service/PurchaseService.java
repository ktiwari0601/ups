package com.cg.mps.service;
import java.util.ArrayList;
import com.cg.mps.exception.*;
import com.cg.mps.dto.*;
public interface PurchaseService {
	public int addCust(Purchase p)throws MobilePurchaseException;

	boolean validateCustName(String ename) throws MobilePurchaseException;
	public boolean validatePhoneNo(String pno) throws MobilePurchaseException;
	public boolean validateMobileId(int mid) throws MobilePurchaseException;
	public boolean validateEmailId(String mailid) throws MobilePurchaseException;
}
