package com.cg.mps.service;

import java.util.ArrayList;

//import com.cg.mps.dao.MobileDaoImpl;
import com.cg.mps.dao.MobileDaoImpl;
import com.cg.mps.dto.Mobile;
import com.cg.mps.exception.MobilePurchaseException;

public class MobileServiceImpl implements MobileService{

	MobileDaoImpl mDao=null;
	public MobileServiceImpl()
	{
		mDao=new MobileDaoImpl();
	}
	@Override
	public ArrayList<Mobile> display() throws MobilePurchaseException {
		// TODO Auto-generated method stub
		return mDao.display();
	}

	@Override
	public int delete(int id) throws MobilePurchaseException {
		// TODO Auto-generated method stub
		return mDao.delete(id);
	}

	@Override
	public ArrayList<Mobile> search(double min, double max) throws MobilePurchaseException {
		// TODO Auto-generated method stub
		return mDao.search(min, max);
	}

}
