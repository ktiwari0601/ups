package com.cg.mps.dto;

import java.sql.Date;

public class Purchase {
	//static int id=0;
	int purchaseId;
	String custName,mailId,phoneNo;
	Date purchaseDate;
	int mobileId;
	public int getPurchaseId() {
		return purchaseId;
	}
	/*public static void setId(int id) {
		Purchase.id = id;
	}*/
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	/*public Date getPurchaseDate() {
		return purchaseDate;
	}
	public void setPurchaseDate(Date purchaseDate) {
		this.purchaseDate = purchaseDate;
	}*/
	public int getMobileId() {
		return mobileId;
	}
	public void setMobileId(int mobileId) {
		this.mobileId = mobileId;
	}
	public Purchase() {
		super();
	}
	public Purchase(String custName, String mailId, String phoneNo, int mobileId) {
		super();
		//id++;
		//this.purchaseId=id;
		this.custName = custName;
		this.mailId = mailId;
		this.phoneNo = phoneNo;
		//this.purchaseDate = purchaseDate;
		this.mobileId = mobileId;
	}
	@Override
	public String toString() {
		return "Purchase [purchaseId=" + purchaseId + ", custName=" + custName + ", mailId=" + mailId + ", phoneNo="
				+ phoneNo + ", purchaseDate=" + purchaseDate + ", mobileId=" + mobileId + "]";
	}
	
	
}
