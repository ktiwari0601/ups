package com.cg.mps.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.mps.dto.Mobile;
import com.cg.mps.exception.MobilePurchaseException;
import com.cg.mps.util.DBUtil;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class MobileDaoImpl implements MobileDao{
	
	//Logger daoLogger=null;
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	int data=0;
	
	/*public EmpDaoImpl()
	{
		daoLogger=Logger.getLogger(EmpDaoImpl.class);
		PropertyConfigurator.configure("log4j.properties");
	}*/
	@Override
	public ArrayList<Mobile> display() throws MobilePurchaseException
	{
		ArrayList<Mobile> mobList=null;
		try
		{
			mobList=new ArrayList<Mobile>();
			con=DBUtil.getConn();
			String selectQry="select * from mobile";
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			
			while(rs.next())
			{
				//dao.info(new Employee(rs.getInt("emp_id"),rs.getString("emp_name"),rs.getFloat("emp_sal")));
				mobList.add(new Mobile(rs.getInt("mobile_id"),rs.getString("name"),rs.getDouble("price"),rs.getString("quantity")));
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new MobilePurchaseException(e.getMessage());
		}
		finally
		{
			try
			{
				st.close();
				rs.close();
				con.close();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
				//daoLogger.error(e.getMessage());
				throw new MobilePurchaseException(e.getMessage());
			}
		}
		//daoLogger.info("All data retrieved \n"+empList);
		// TODO Auto-generated method stub
		return mobList;
	}

	@Override
	public int delete(int id) throws MobilePurchaseException {
		// TODO Auto-generated method stub
		try {
			con=DBUtil.getConn();
			String deleteQry="delete from mobile where mobile_id=?";
			pst=con.prepareStatement(deleteQry);
			pst.setInt(1,id);
			data = pst.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new MobilePurchaseException(e.getMessage());
		}
		
		return data;
		//return 0;
	}

	@Override
	public ArrayList<Mobile> search(double min, double max) throws MobilePurchaseException {
		// TODO Auto-generated method stub
		//return null;
		ArrayList<Mobile> mobList=null;
		try
		{
			mobList=new ArrayList<Mobile>();
			con=DBUtil.getConn();
			String selectQry="select * from mobile where price>=? and price<=?";
			pst=con.prepareStatement(selectQry);
			pst.setDouble(1,min);
			pst.setDouble(2,max);
			rs=pst.executeQuery();
			while(rs.next())
			{
				//dao.info(new Employee(rs.getInt("emp_id"),rs.getString("emp_name"),rs.getFloat("emp_sal")));
				mobList.add(new Mobile(rs.getInt("mobile_id"),rs.getString("name"),rs.getDouble("price"),rs.getString("quantity")));
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new MobilePurchaseException(e.getMessage());
		}
		//daoLogger.info("All data retrieved \n"+empList);
		// TODO Auto-generated method stub
		return mobList;
	}
}
