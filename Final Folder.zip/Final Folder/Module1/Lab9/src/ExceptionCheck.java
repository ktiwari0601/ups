public class ExceptionCheck extends Exception{
	public String toString()
	{
		return "Salary should be greater than or equal to 3000";
	}
}
