package com.cg.eis.pl;

import java.util.Scanner;
import com.cg.eis.bean.Employee;
import com.cg.eis.service.EmployeeServiceImplement;
public class EmployeeMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String des="",id="";
		System.out.println("Enter the employee id:");
		id=sc.nextLine();
		System.out.println("Enter the salary:");
		double salary=sc.nextDouble();
		System.out.println("Enter designation:");
		des=sc.next();
		Employee obj=new Employee(id,des,salary);
		EmployeeServiceImplement ser=new EmployeeServiceImplement(obj);
	}

}
