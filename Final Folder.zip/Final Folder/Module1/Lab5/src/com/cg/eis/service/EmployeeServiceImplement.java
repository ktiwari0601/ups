package com.cg.eis.service;
import com.cg.eis.bean.Employee;
import java.util.Scanner;

interface EmployeeService {
	String findInsScheme(double salary);
	void display(Employee emp);
}

public class EmployeeServiceImplement implements EmployeeService{
	public EmployeeServiceImplement(Employee emp)
	{
		display(emp);
	}
	public String findInsScheme(double salary)
	{
		String ins="";
		if(salary<5000)
		{
			ins="No insurance";
		}
		else if(salary>=5000 && salary<20000)
		{
			ins="Sceheme C";
		}
		else if(salary>=20000 && salary<40000)
		{
			ins="Scheme B";
		}
		else if(salary>=40000)
		{
			ins="Scheme A";
		}
		return ins;
	}
	public void display(Employee emp)
	{
		System.out.println("Employee Details:");
		System.out.println("******************");
		System.out.println("Emp Id:"+emp.getEmpId());
		System.out.println("Designation:"+emp.getDesig());
		System.out.println("Salary:"+emp.getSalary());
		System.out.println("Insurance:"+findInsScheme(emp.getSalary()));
		
	}
}
