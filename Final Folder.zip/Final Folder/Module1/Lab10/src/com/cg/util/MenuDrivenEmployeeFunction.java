package com.cg.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class MenuDrivenEmployeeFunction {
	public static void main(String args[])
	{
		Connection con=null;
		PreparedStatement pst=null;
		Statement st=null;
		ResultSet rs=null;
		Scanner sc=new Scanner(System.in);
		while(true)
		{
			System.out.println("1)Insert \n2)Display \n3)Delete \n4)exit \nEnter the your choice:");
			int c=sc.nextInt();
			switch(c)
			{
			case 1:
				System.out.println("Enter emp id:");
				int id=sc.nextInt();
				System.out.println("Enter emp name:");
				String name=sc.next();
				System.out.println("Enter emp salary:");
				float sal=sc.nextFloat();
				String insertQry="insert into Emp_157903 values (?,?,?)";
				try {
					Class.forName("oracle.jdbc.driver.OracleDriver");
					con=DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G","lab1btrg17","lab1boracle");
					pst=con.prepareStatement(insertQry);
					pst.setInt(1,id);
					pst.setString(2,name);
					pst.setFloat(3,sal);
					int noOfRecInserted=pst.executeUpdate();
					System.out.println(noOfRecInserted +" data inserted into the table");
					
				} 
				catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 2:
				try {
					Class.forName("oracle.jdbc.driver.OracleDriver");
					con=DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G","lab1btrg17","lab1boracle");
					st=con.createStatement();
					rs=st.executeQuery("Select * from Emp_157903");
					while(rs.next())
					//);
					System.out.println(" : " +rs.getInt("emp_id")+" : "+rs.getString("emp_name")+" : "+rs.getFloat("emp_sal"));
				} 
				catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 3:
				System.out.println("Enter emp id to be deleted:");
				int di=sc.nextInt();
				String deleteQry="delete from Emp_157903 where emp_id=?";
				
				
				try {
					Class.forName("oracle.jdbc.driver.OracleDriver");
					con=DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G","lab1btrg17","lab1boracle");
					pst=con.prepareStatement(deleteQry);
					pst.setInt(1,di);
					//pst.setString(2,name);
					//pst.setFloat(3,sal);
					int noOfRecDeleted=pst.executeUpdate();
					System.out.println(noOfRecDeleted +" records deleted from the table");
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 4:
				System.exit(0);
				
			}
		}
		
		
		
		
		
	}
}
