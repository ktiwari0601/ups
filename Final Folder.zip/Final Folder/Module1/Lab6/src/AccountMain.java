
public class AccountMain {
	public static void main(String args[])
	{
		Person obj1=new Person("Smith","S",'m',8);
		//Account a1=new Account(2000,obj1);
		Person obj2=new Person("Kathy","K",'f',24);
		//Account a2=new Account(3000,obj2);
		//a1.deposit(2000);
		//a2.withdraw(2000);
		//System.out.println("Balance in Smith Account:"+a1.getBalance());
		//System.out.println("Balance in Kathy Account:"+a2.getBalance());
	}
}
