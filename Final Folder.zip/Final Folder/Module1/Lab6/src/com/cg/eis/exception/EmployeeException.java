package com.cg.eis.exception;

public class EmployeeException extends Exception{
	public String toString()
	{
		return "Salary should be greater than or equal to 3000";
	}
}
