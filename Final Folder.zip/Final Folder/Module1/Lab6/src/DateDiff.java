import java.time.LocalDate;
import java.time.Month;
import java.time.Period;
import java.util.Scanner;
import java.time.format.DateTimeFormatter;
//import java.time.format.FormatStyle;

public class DateDiff {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yy");
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter date prior to 17/08/18 in dd/MM/yy format:");
		String input = sc.nextLine();		
		LocalDate enteredDate = LocalDate.parse(input,formatter);
		LocalDate end = LocalDate.now();
		Period period = enteredDate.until(end);
				
		System.out.println("Days:"+ period.getDays());
		System.out.println("Months:"+period.getMonths());
		System.out.println("Years:"+ period.getYears());
	}
}
