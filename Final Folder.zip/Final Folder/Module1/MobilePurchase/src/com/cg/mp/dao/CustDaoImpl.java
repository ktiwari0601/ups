package com.cg.mp.dao;
import java.sql.*;
import java.util.ArrayList;
import java.util.Calendar;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.mp.dto.Mobile;
import com.cg.mp.dto.Customer;
import com.cg.mp.exception.CustException;
import com.cg.mp.util.DBUtil;

public class CustDaoImpl implements CustDao
{
	Logger myLogger=Logger.getLogger(CustDaoImpl.class);
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs =null;
	@Override
	public ArrayList<Mobile> getAllMobile() throws CustException
	{
		ArrayList<Mobile> mobList;
		try
		{
			mobList = new ArrayList<Mobile>();
			con=DBUtil.getconn();
			System.out.println("********con in dao*******"+con);
			String selectqry="SELECT * from mob";
			st=con.createStatement();
			rs=st.executeQuery(selectqry);
			while(rs.next())
			{
				mobList.add(new Mobile(rs.getInt("mobid"),rs.getString("name"),rs.getFloat("price"),rs.getString("quantity")));
			}
		}
		catch(Exception e)
			{
				e.printStackTrace();
				throw new CustException("Error");
			}
		finally
		{
			try
			{
				st.close();
				rs.close();
				con.close();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
				throw new CustException(e.getMessage());
			}
		}
		return mobList;
	}
	@Override
public int deleteMob(int mid) throws CustException
{
	int data;
	try 
	{
		con=DBUtil.getconn();
		String insertQry = "DELETE FROM Mob WHERE mobid=? ";
		pst=con.prepareStatement(insertQry);
		pst.setInt(1,mid);
		data=pst.executeUpdate();
		if(data==1)
		{
			System.out.println("DELETED");
		}
		else
		{
			System.out.println("NOT DELETED");
		}
	} 
	catch (Exception e) 
	{
		//e.printStackTrace();
		throw new CustException("Not deleted");
	} 
	finally
	{
		try
		{
			pst.close();
			// rs.close();
			con.close();
		}
		catch(SQLException e)
		{
			//e.printStackTrace();
			throw new CustException(e.getMessage());
		}
	}
	return data;
}
	public ArrayList<Mobile> searchMob(float lowprice,float highprice) throws CustException
	{
		PropertyConfigurator.configure("log4j.properties");
		ArrayList<Mobile> searchList;
		try
		{
			con=DBUtil.getconn();
			searchList = new ArrayList<Mobile>();
			String selectqry="SELECT * FROM mob WHERE price>=? and price<?";
			pst=con.prepareStatement(selectqry);
			pst.setFloat(1,lowprice);
			pst.setFloat(2,highprice);
			rs=pst.executeQuery();
			
		while(rs.next())
		{
			searchList.add(new Mobile(rs.getInt("mobid"),rs.getString("name"),rs.getFloat("price"),rs.getString("quantity")));
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new CustException("Does Not Exist");
		}
		return searchList;
	}
	public int addCust(Customer c) throws CustException
	{
		PropertyConfigurator.configure("log4j.properties");
		int quant = 0;
		int noOfRows=0;
		try
		{
		con=DBUtil.getconn();
		String insertQry = "SELECT quantity FROM mob WHERE mobid=? ";
		pst=con.prepareStatement(insertQry);
		pst.setInt(1,c.getMobileId());
		rs=pst.executeQuery();
		while(rs.next())
		{
			quant=rs.getInt("quantity");
		}
		if(quant>0)
		{
			String insertQry1 = "INSERT INTO purdet VALUES(?,?,?,?,?,?) ";
			pst=con.prepareStatement(insertQry1);
			pst.setInt(1,  c.getPurId());
			pst.setString(2,  c.getCusName());
			pst.setString(3,  c.getMailId());
			pst.setString(4,  c.getPhnNo());
			
			Calendar currenttime = Calendar.getInstance();
			Date sqldate = new Date((currenttime.getTime().getTime()));
			pst.setDate(5, (java.sql.Date)sqldate);
			pst.setInt(6, c.getMobileId());
			noOfRows=pst.executeUpdate();
			
			String qry="UPDATE mob Set quantity =? WHERE mobid=?";
			pst=con.prepareStatement(qry);
			quant-=1;
			pst.setInt(1, quant);
			pst.setInt(2,  c.getMobileId());
			int noOfRecAffected=pst.executeUpdate();
			System.out.println( noOfRecAffected +"Purchase Details inserted");
			myLogger.info("Data Inserted"+c);
		}
		else
		{
			myLogger.error("Data cannot be Inserted");
			throw new CustException("Not inserted");
		}
	}
	catch(Exception e)
	{
		e.printStackTrace();
		throw new CustException("Not inserted");
	}
	finally
	{
		try
		{
			pst.close();
			rs.close();
			con.close();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			throw new CustException(e.getMessage());
		}
	}
	
	return noOfRows;
}
}
