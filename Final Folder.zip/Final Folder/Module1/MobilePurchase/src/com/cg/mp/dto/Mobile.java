package com.cg.mp.dto;

import java.util.ArrayList;

public class Mobile {
	
	@Override
	public String toString() {
		return "Mobile [mobId=" +mobId + ", Name=" + name
				+ ", price=" + price + ", quantity=" + quantity +"]";
	}
        private int mobId;
	private String quantity;
	private String name;
	private float price;
	private float lowprice;
	private float highprice;
	public int getMobId() {
		return mobId;
	}
	public void setMobId(int mobId) {
		this.mobId = mobId;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public Mobile() {
		super();
	}
	public Mobile(int mobId, String name, float price,String quantity) {
		super();
		this.mobId = mobId;
		this.name = name;
		this.price = price;
		this.quantity = quantity;
	}
	public static ArrayList<Mobile> getAllMob() {
		return Mobile.getAllMob();
	}
	public float getHighprice() {
		return highprice;
	}
	public void setHighprice(float highprice) {
		this.highprice = highprice;
	}
	public float getLowprice() {
		return lowprice;
	}
	public void setLowprice(float lowprice) {
		this.lowprice = lowprice;
	}
}
