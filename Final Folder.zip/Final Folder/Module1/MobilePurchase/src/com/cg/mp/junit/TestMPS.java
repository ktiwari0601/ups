package com.cg.mp.junit;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.mp.dao.CustDaoImpl;
import com.cg.mp.dto.Customer;
import com.cg.mp.exception.CustException;

public class TestMPS {
	static CustDaoImpl cc = null;
	static Customer c=null;
	@BeforeClass
	public static void setUp()
	{
		c = new Customer(4567,"Dipti","dipti03@gmail.com","9812309846","09-09-2016",1003);
		cc = new CustDaoImpl();
		System.out.println("setUp is call once" + " Before the execution of " + "all test cases");	
	}
	@AfterClass
	public static void teardown()
	{
		System.out.println("init is call once" + " After the execution of " + "each test cases");
	}
	@Before
	public void init()
	{
		System.out.println("init is call once" + " Before the execution of " + "each test cases");
	}
	@After
	public void destroy()
	{
		System.out.println("destroy is call once" + " After the execution of " + "each test cases");
	}
    @Test
	public void testDivide1()
	{
		try {
			Assert.assertEquals(1, cc.addCust(c));
		} catch (CustException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}


