package com.cg.mp.dto;

public class Customer {
	private int purId;
	private String cusName;
	private String mailId;
	private String phnNo;
	private String purDate;
	private int mobileId;
	@Override
	public String toString() {
		;
		return "Customer [purId=" +purId + ", cusName=" + cusName
				+ ", mailId=" + mailId + ", phnNo=" + phnNo +", purDate=" + purDate +", mobileId=" + mobileId +"]";
	}
	public int getPurId() {
		return purId;
	}
	public void setPurId(int purId) {
		this.purId = purId;
	}
	public String getCusName() {
		return cusName;
	}
	public void setCusName(String cusName) {
		this.cusName = cusName;
	}
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	public String getPhnNo() {
		return phnNo;
	}
	public void setPhnNo(String phnNo) {
		this.phnNo = phnNo;
	}
	public String getPurDate() {
		return purDate;
	}
	public void setPurDate(String purDate) {
		this.purDate = purDate;
	}
	public int getMobileId() {
		return mobileId;
	}
	public void setMobileId(int mobileId) {
		this.mobileId = mobileId;
	}
	public Customer() {
		super();
	}
	public Customer(int purId, String cusName, String mailId, String phnNo,String purDate, int mobileId) 
	{
		super();
		this.purId = purId;
		this.cusName = cusName;
		this.mailId = mailId;
		this.phnNo = phnNo;
		this.purDate = purDate;
		this.mobileId = mobileId;
	}
}
