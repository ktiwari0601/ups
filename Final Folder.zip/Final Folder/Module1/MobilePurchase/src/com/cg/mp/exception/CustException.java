package com.cg.mp.exception;
import com.cg.mp.exception.ErrorCode;
	public class CustException extends Exception 
	{
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		String msg;
		static ErrorCode code;
		public CustException(String msg)
		{
			super(msg);
		}
		public CustException(String msg, Throwable cause,ErrorCode code) 
		{
			super(msg,cause);
		}

}
