//import java.util.HashMap;
import java.util.Scanner;

public class EmployeeMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//HashMap<String,Employee> directory=new HashMap<String,Employee>();
		Scanner sc=new Scanner(System.in);
		String des="",id="";
		System.out.println("Enter the number of employees:");
		int n=sc.nextInt();
		EmployeeInsurance obj=new EmployeeInsurance();
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter the employee id:");
			id=sc.next();
			System.out.println("Enter the salary:");
			double salary=sc.nextDouble();
			System.out.println("Enter designation:");
			des=sc.next();
			System.out.println("Enter insurance scheme:");
			String ins=sc.next();
			Employee emp=new Employee(id,des,ins,salary);
			
			obj.add(id,emp);
		}
		System.out.println("Enter the id of the employee to be deleted:");
		String di=sc.next();
		//EmployeeInsurance obj1=new EmployeeInsurance();
		obj.delete(di);
		System.out.println("Enter the insurance scheme(A/B/C):");
		String in=sc.next();
		System.out.println("Employees present under the insurance scheme "+in+" are:");
		obj.search(in);
		System.out.println("Sorting accorrding to salaries:");
		obj.sort();
		//obj.print();
	}
}
