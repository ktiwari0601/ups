public class AccountMain 
{
public static void main(String[]args)
{
	Person p=new Person("Smith",22);
	Person p1=new Person("Katty",17);
	Account a=new Account(123456789,2000,p);
	Account a1=new Account(234156709,3000,p1);
	System.out.println("Smith deposit successful : "+a.deposit(2000));
	System.out.println("Katty withdrawl successful : "+a1.withdraw(1000));
	System.out.println("Smith balance : "+a.getbalance());
	System.out.println("Katty balance : "+a1.getbalance());
}
}
