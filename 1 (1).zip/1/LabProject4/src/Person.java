public class Person 
{
String name;
float age;
Person()
{ }
Person(String name,float age)
{
	this.name=name;
	this.age=age;
}
}

