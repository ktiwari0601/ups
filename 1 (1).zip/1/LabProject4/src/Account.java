public class Account 
{
	long accNum;
	double balance;
	Person accHolder;
	private Object withdraw;
	@SuppressWarnings("unused")
	private Object deposit;
	Account()
	{ }
	Account(long a,double b,Person p)
	{
		this.accNum=a;
		this.balance=b;
		accHolder=new Person();
		accHolder.name=p.name;
		try
		{
			if(p.age<18)
			{
				throw new MyException();
			}
			accHolder.age=p.age;
		}
		catch(MyException e)
		{
			System.out.println(e);
		}
	}
	public boolean withdraw(int i) 
	{
		this.setWithdraw(balance-i);
		return false;
	}
	public boolean deposit(int i) 
	{
		// TODO Auto-generated method stub
		 this.setDeposit(balance+i);
		 return true;
	}
	public int getbalance() {
		// TODO Auto-generated method stub
		return (int) balance;
	}
	public Object getWithdraw() {
		return withdraw;
	}
	public void setWithdraw(Object withdraw) {
		this.withdraw = withdraw;
	}
	public Object getDeposit() {
		return deposit=+balance;
	}
	public void setDeposit(Object deposit) {
		this.deposit = deposit;
	}
	
}
	