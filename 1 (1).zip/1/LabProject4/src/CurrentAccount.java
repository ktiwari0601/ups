public class CurrentAccount extends Account
{
 double overdraftlimit=1000;
 public boolean withdraw(double d)
 {
	 if(d>=overdraftlimit)
	 {
		 return true;
	 }
	 @SuppressWarnings("unused")
	double balance =-d;
	 return false;
 }
}
