public class SavingsAccount extends Account 
{
 final double MinimumBalance=500;
 public boolean withdraw(double d)
 {
	 if(balance-d>=MinimumBalance)
	 {
		 balance-=d;
		 return true;
	 }
	 return false;
 }
}
