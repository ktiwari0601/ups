package com.cg;
	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.PreparedStatement;
	import java.sql.SQLException;
	import java.util.Scanner;
	public class DeleteDemo 
	{
		@SuppressWarnings("resource")
		public static void main(String[] args)
		{
			Connection con = null;
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter Emp Id : ");
			int EmpId = sc.nextInt();
			
			String insertQry = "Delete From Employee_25 where Emp_Id = ?";
			
			try 
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
				con=DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:orcl11g",
						"lab1btrg25","lab1boracle");
				PreparedStatement pst = con.prepareStatement(insertQry);
				pst.setInt(1,EmpId);
				
				int noOfRecAffected=pst.executeUpdate();
				System.out.println(noOfRecAffected + " record deleted");
			}
			catch (ClassNotFoundException e) 
			{
				e.printStackTrace();
			}
			catch ( SQLException e) 
			{
				e.printStackTrace();
			}
		}
	}

