package com.cg;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class TestEmpInsertDemo 
{
	@SuppressWarnings("resource")
	public static void main(String[] args)
	{
		Connection con = null;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Emp Id : ");
		int EmpId = sc.nextInt();
		System.out.println("Enter Emp Name : ");
		String Ename = sc.next();
		System.out.println("Enter Emp Sal : ");
		int Esal = sc.nextInt();
		
		String insertQry = "INSERT INTO Employee_25 values(?,?,?)";
		
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:orcl11g",
					"lab1btrg25","lab1boracle");
			PreparedStatement pst = con.prepareStatement(insertQry);
			pst.setInt(1,EmpId);
			pst.setString(2,Ename);
			pst.setInt(3,Esal);
			
			int noOfRecAffected=pst.executeUpdate();
			System.out.println(noOfRecAffected + " record is inserted in the table ");
		}
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		}
		catch ( SQLException e) 
		{
			e.printStackTrace();
		}
	}
}
