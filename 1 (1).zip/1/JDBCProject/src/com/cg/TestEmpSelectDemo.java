package com.cg;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class TestEmpSelectDemo 
{
	public static void main(String[ ] args)
	{
		Connection con = null;
		Statement st = null;
		ResultSet rs = null;
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:orcl11g",
					"lab1btrg25","lab1boracle");
			
			st = con.createStatement();
			rs = st.executeQuery("SELECT * FROM Employee_25");
			System.out.println(" -----Result Set Meta Data----");
			ResultSetMetaData rsmd=rs.getMetaData();
			int colCount = rsmd.getColumnCount();
			System.out.println(" No of Column : "+colCount);
			for(int i=1;i<=colCount;i++)
			{
				System.out.println(" Column name : "+rsmd.getColumnName(i) + " , Column Data Type : " +rsmd.getColumnTypeName(i));
			}
            while(rs.next())
            {
			System.out.println(" "+rs.getInt("Emp_id")+ " : " +rs.getString("Ename")+ " : "+rs.getInt("Esal"));
            }
		} 
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		}
		catch ( SQLException e) 
		{
			e.printStackTrace();
		}
	}
}
