import java.util.ArrayList;
import java.util.Iterator;
public class Persondetails 
{
	public static void main(String [] args)
	{

		ArrayList<String> str=new ArrayList<String>();
		String s1= new String("First name : Sania");
		String s2= new String("Last name : Khan");
		String s3= new String("Gender : F");
		String s4= new String("Age : 22");
		String s5= new String("Weight :85.55");
		str.add(s1);
		str.add(s2);
		str.add(s3);
		str.add(s4);
		str.add(s5);
		Iterator<String> itString=str.iterator();
		while(itString.hasNext())
		{
			String values=itString.next();
			System.out.println(""+values);
		}
}
}
