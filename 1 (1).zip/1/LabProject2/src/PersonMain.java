import java.util.Scanner;
public class PersonMain {
	public static void main(String args[])
	{
			String a,b = null;
			@SuppressWarnings("resource")
			Scanner sc=new Scanner(System.in);
			try
			{
				System.out.println("Enter fN");
				a=sc.nextLine();
				if(a.equals(""))
					throw new MyException();
				@SuppressWarnings("unused")
				Person p = new Person(a,b,'F');
			}
			catch(MyException e)
			{
				System.out.println("Exception:" +e);
			}
	}
}
