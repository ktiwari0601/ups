public class Person {
	String fN;
	String lN;
	char g;
	Person()
	{
		System.out.println("class Person");
	}
	Person(String fN, String lN, char g)
	{
		this.fN=fN;
		this.lN=lN;
		this.g=g;
	}
}
