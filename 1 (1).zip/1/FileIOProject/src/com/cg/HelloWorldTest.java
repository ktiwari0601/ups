package com.cg;
import static org.junit.Assert.*;
import org.junit.Test;

public class HelloWorldTest {
	@Test
	public void testsay()
	{
		HelloWorld hello=new HelloWorld();
		assertEquals("Unexpected Result","Hello World",hello.say());
	}

}
