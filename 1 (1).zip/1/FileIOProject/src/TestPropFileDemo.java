import java.io.*;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;
public class TestPropFileDemo 
{
	@SuppressWarnings("rawtypes")
	public static void main(String[] args)
	{
		FileInputStream fis = null;
		Properties myProps = null;
		try
		{
			fis = new FileInputStream("userinfor");
			myProps = new Properties();
			myProps.load(fis);
			String unm = myProps.getProperty("UserId");
			String pwd = myProps.getProperty("Password");
			System.out.println("Credentials : "+ unm + " : "+pwd);
			System.out.println(" ****************** ");

			Set kS = myProps.keySet();
			Iterator it = kS.iterator();
			while(it.hasNext())
			{
				System.out.print("   " +it.next());
			}
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
}
