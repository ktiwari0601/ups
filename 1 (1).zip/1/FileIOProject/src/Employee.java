import java.io.Serializable;
public class Employee implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	int empId;
	String empName;
	float empSal;
	
	public Employee()
	{ }
	public Employee(int empId, String empName, float empSal)
	{
		super();
		this.empId=empId;
		this.empName=empName;
		this.empSal=empSal;
	}
	public String toString()
	{
		return("empId = +empId ");
	}
}
