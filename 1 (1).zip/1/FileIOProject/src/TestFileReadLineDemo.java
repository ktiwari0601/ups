import java.io.*;
public class TestFileReadLineDemo 
{
	public static void main(String[] args)
	{
		File myFile=new File("D:/SANIA KHAN/FileIOProject/src/TestEmpReadDemo.java");
		FileWriter fw =null;
		FileReader fr = null;
		BufferedWriter bw=null;
		BufferedReader br= null;
		try
		{
			fr = new FileReader(myFile);
			br = new BufferedReader(fr);
			fw = new FileWriter("MyFile.txt");
			bw = new BufferedWriter(fw);
			String line = br.readLine();
			while(line!=null)
			{
				System.out.println(line);
				bw.write(line);
				bw.flush();
				line=br.readLine();
			}	
			System.out.println("All Data written in the file");
		}
			catch (IOException e) 
		{
				// TODO Auto-generated catch block
				e.printStackTrace();
		}	
	}
}
