import java.io.*;
public class TestFileReadDemo 
{
	public static void main(String[] args)
	{
		File myFile=new File("D:/SANIA KHAN/FileIOProject/src/TestEmpReadDemo.java");
		FileInputStream fis =null;
		try
		{
			fis = new FileInputStream(myFile);
			int data=fis.read();
			while(data!=-1)
			{
				System.out.print((char)data);
				data=fis.read();
			}	
		}
			catch (NumberFormatException | IOException e) 
		{
				// TODO Auto-generated catch block
				e.printStackTrace();
		}	
	}
}
