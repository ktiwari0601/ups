
public interface MaxFinder {

	String max(int i, int j);

}
