public class MaxFinderImpl implements MaxFinder
{
	public  (int a,int b)

}
