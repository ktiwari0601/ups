import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;
public class TestStreamAPIDemo {
	public static void main(String []args)
	{
		List<Integer> intList=Arrays.asList(45,10,5,10,8,28,875);
		Stream<Integer> intListStream=intList.stream();
		intListStream.filter((num)->num>10).forEach(num->System.out.println(num));
		System.out.println("*******print distance*******");
		intList.stream().distinct().forEach(num->System.out.println(" : " +num));
		
		intList.stream().distinct().forEach(System.out::println);
		System.out.println("**************");
		List<String> cityList = Arrays.asList("Pune","","Mumbai","Bangalore","","Chennai","");
		cityList.stream().map(str->str.length()).forEach(System.out::println);
		System.out.println("**************");
		long countofEmptyStr=cityList.stream().filter(str->str.isEmpty()).count();
		System.out.println("How many empty streams ?" +countofEmptyStr);
	}

}
