package com.cg.ems.exception;
public class EmpException extends Exception 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String msg;
	static ErrorCode code;
	public EmpException(String msg)
	{
		super(msg);
	}
	public EmpException(String msg, Throwable cause,ErrorCode code) 
	{
		super(msg,cause);
	}
	
}
