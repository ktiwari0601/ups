package com.cg.ems.util;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBUtil 
{
	static String driver=null;
	static String url=null;
	static String user=null;
	static String password=null;
	@SuppressWarnings("unused")
	public static Connection getconn() throws SQLException, IOException
	{
		Properties myProps = loadDBInfo();
		driver=myProps.getProperty("dbDriver");
		url=myProps.getProperty("dbUrl");
		user=myProps.getProperty("dbUser");
		password=myProps.getProperty("dbPassword");
		Connection con = null;
		if(con==null)
		{
			con=DriverManager.getConnection(url,user,password);
			System.out.println(" In DB Util con is null" +con);
			return con;
		}
		else
		{
			return con;
		}
	}
	public static Properties loadDBInfo() throws IOException
	{
		FileReader fr=new FileReader("dbinfo.properties");
		Properties dbProps=new Properties();
		dbProps.load(fr);
		return dbProps;
	}
}
