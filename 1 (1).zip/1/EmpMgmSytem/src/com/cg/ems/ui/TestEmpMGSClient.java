package com.cg.ems.ui;
import java.util.ArrayList;
import java.util.Scanner;
import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmpException;
import com.cg.ems.service.EmpService;
import com.cg.ems.service.EmpServiceImpl;

public class TestEmpMGSClient 
{
	static EmpService empservice = null;
	static Scanner sc = null;
	public static void main(String[] args) 
	{
		sc = new Scanner(System.in);
		empservice=new EmpServiceImpl();
		int choice = 0;
		System.out.println("****Welcome to EMS****");
		while(true)
		{
			System.out.println("What to you want to do?");
			System.out.println("\t 1:Add Emp\t 2:Show All Emp" +"\t 3: Update Emp \t 4 : Delete Emp \t\n" +"\t 5 : Exit +");
			System.out.println("Enter your Choice");
			choice=sc.nextInt();
			
			switch(choice)
			{
			case 1 : insertEmp();break;
			case 2 : dispAllemp();break;
			default : System.exit(0);
			}
		}
	}
	private static void dispAllemp() 
	{
		ArrayList<Employee> empList;
		try 
		{
			empList = empservice.getAllEmp();
			System.out.println(" \tEMPID \tENAME \tESAL");
			for(Employee ee:empList)
			{
				System.out.println("\t"+ee.getEmpId()+"\t"+ee.getEmpName() + "\t" +ee.getEmpSal());
			}
		} 
		catch (EmpException e) 
		{
			e.printStackTrace();
		}
	}
	private static void insertEmp() 
	{
		try {
			System.out.println("Enter your Emp id");
			int eId = sc.nextInt();
			System.out.println("Enter Name");
			String enm = sc.next();
			float esl=0.0F;
			if(empservice.validateEmpName(enm))
			{
				System.out.println("Enter Salary");
				esl=sc.nextFloat();
				Employee e1= new Employee(eId,enm,esl);
				int dataInserted=empservice.addEmp(e1);
				if(dataInserted==1)
				{
					dispAllemp();
				}
				else
				{
					System.out.println("Sorry data is" +"not inserted");
				}
			}
			else
			{
				System.out.println("Insert correct name");
			}
		} 
		catch (EmpException e) 
		{
			e.printStackTrace();
		}
	}

}
