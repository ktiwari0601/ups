package com.cg.ems.service;
import java.util.ArrayList;
import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmpException;
public interface EmpService 
{
	public ArrayList<Employee> getAllEmp() throws EmpException;
	public int addEmp(Employee ee) throws EmpException;
	public boolean validateEmpName(String eName) throws EmpException;
}
