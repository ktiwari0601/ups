package com.cg.ems.service;
import java.util.ArrayList;
import java.util.regex.Pattern;
import com.cg.ems.dao.EmpDaoImpl;
import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmpException;

public class EmpServiceImpl implements EmpService
{
	EmpDaoImpl empDao=null;
	public EmpServiceImpl()
	{
		empDao=new EmpDaoImpl();
	}
	@Override
	public ArrayList<Employee> getAllEmp() throws EmpException 
	{
		return empDao.getAllEmp();
	}
	@Override
	public int addEmp(Employee ee) throws EmpException 
	{
		return empDao.addEmp(ee);
	}
	@Override
	public boolean validateEmpName(String eName) throws EmpException 
	{
		String namePattern="[A-Z][a-z]+";
		if(Pattern.matches(namePattern, eName))
		{
			return true;
		}
		else
		{
			throw new EmpException("Invalid Empl Name Should Start with capital" +"Only characters allowed");
		}
	}

}
