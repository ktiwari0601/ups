package com.cg.ems.dao;
import java.io.IOException;
import java.util.ArrayList;

import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmpException;
public interface EmpDao 
{
	public ArrayList<Employee> getAllEmp() throws EmpException;
	public int addEmp(Employee ee) throws EmpException, IOException;

}
