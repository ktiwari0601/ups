package com.cg.ems.dao;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;

import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmpException;
import com.cg.ems.util.DBUtil;

public class EmpDaoImpl implements EmpDao
{
		Connection con=null;
		Statement st=null;
		PreparedStatement pst=null;
		ResultSet rs =null;
	@Override
	public ArrayList<Employee> getAllEmp() throws EmpException
	{
		ArrayList<Employee> empList=null;
		try
		{
			empList = new ArrayList<Employee>();
			con=DBUtil.getconn();
			System.out.println("********con in dao*******"+con);
			String selectqry="SELECT * from Employee_25";
			st=con.createStatement();
			rs=st.executeQuery(selectqry);
			while(rs.next())
			{
				empList.add(new Employee(rs.getInt("emp_id"),rs.getString("Ename"),rs.getFloat("Esal")));
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new EmpException(e.getMessage());
		}
		finally
		{
			try
			{
				st.close();
				rs.close();
				con.close();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
				throw new EmpException(e.getMessage());
			}
		}
		return empList;
	}

	@Override
	public int addEmp(Employee ee) throws EmpException
	{
		int data;
		try 
		{
			con=DBUtil.getconn();
			String insertQry = "INSERT INTO Employee_25 VALUES(?,?,?) ";
			pst=con.prepareStatement(insertQry);
			pst.setInt(1,  ee.getEmpId());
			pst.setString(2,  ee.getEmpName());
			pst.setFloat(3,  ee.getEmpSal());
			data=pst.executeUpdate();
		} 
		catch (SQLException | IOException e) 
		{
			e.printStackTrace();
			throw new EmpException(e.getMessage());
		} 
		return data;
	}
}