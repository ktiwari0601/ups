import java.util.Scanner;
public class TestArrayDemo 
{
	private static final int empCount = 0;
	public static void main(String [] args)
	{
	int [] marks = new int[3];
	marks[0]=90;
	marks[1]=80;
	marks[2]=70;
	for(int i=0; i<marks.length; i++)
	{
		System.out.println("marks["+"i"+"]:" + marks[i]);
	}
	int nums[]=null;
	nums=new int[3];
	nums[0]=90;
	nums[1]=80;
	nums[2]=70;
	System.out.println("*************");
	System.out.println("******2P*****");	
	int A[][]=new int[3][2];
	A[0][0]=90;
	A[0][1]=80;
	A[1][0]=70;
	A[1][1]=60;
	A[2][0]=20;
	A[2][1]=40;
	System.out.println("**Emp Array**");
	@SuppressWarnings("resource")
	Scanner sc=new Scanner(System.in);
	Emp emps[]=new Emp[empCount];
	
	for(int i=0;i<emps.length;i++)
	{
		System.out.println("Enter Emp Id :");
		int eId=((Scanner) sc).nextInt();
		System.out.println("Enter Emp Name :");
		String eName=((Scanner) sc).next();
		System.out.println("Enter Emp Salary :");
		float eSal=((Scanner) sc).nextFloat();
		emps[i]=new Emp(eId,eName,eSal);
	}
	System.out.println("*************");
}
}
