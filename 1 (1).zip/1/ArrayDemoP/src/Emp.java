@SuppressWarnings("rawtypes")
public class Emp implements Comparable
{
	int empId;
	String empName;
	float empSal;
	public Emp()
	{	}
	public Emp(int empId, String empName, float empSal)
	{
		this.empId=empId;
		this.empName=empName;
		this.empSal=empSal;
	}
	public String toString()
	{
		return "Emp [empId=" + empId + ", empName=" + empName + ", empSal=" + empSal + "]";
	}
	public boolean equals(Object obj)
	{
		Emp ee=(Emp)obj;
		if(this.empId==ee.empId)
		{
		return true;
		}
		else
		{
			return false;
		}
	}
		public int compareTo(Emp ee1)
		{
			if(this.empId<ee1.empId)
			{
				return -1;
			}
			else if(this.empId==ee1.empId)
			{
				return 0;
			}
			else
			{
				return +1;
			}
		}
		@Override
		public int compareTo(Object arg0) {
			// TODO Auto-generated method stub
			return 0;
		}
}

