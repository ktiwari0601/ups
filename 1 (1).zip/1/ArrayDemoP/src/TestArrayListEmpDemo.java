import java.util.ArrayList;
import java.util.Iterator;
public class TestArrayListEmpDemo 
{
	public static void main(String[]args)
	{
		ArrayList<Emp> empList=new ArrayList<Emp>();
		Emp e1=new Emp(112081, "Sania S",9000.0F);
		Emp e2=new Emp(112082, "Sneha B",1000.0F);
		Emp e3=new Emp(112084, "Vaishali K",4000.0F);
		Emp e4=new Emp(112090, "Abhishek C",9000.0F);

		empList.add(e1);
		empList.add(e2);
		empList.add(e3);
		empList.add(e4);

		Iterator<Emp> itEmp=empList.iterator();
		while(itEmp.hasNext())
		{
			System.out.println(""+itEmp.next());
		}
	}
	
}