import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.Iterator;
public class TestHashMapDemo 
{
	public static void main(String[] args)
	{
		HashMap<Long,String> directory=new
				HashMap<Long,String>();
		directory.put(9999199919L, "VaishaliK");
		directory.put(9865535118L, "AmjulataM");
		directory.put(9873390113L, "SaniaK");
		directory.put(9999876519L, "AnshikhaD");
		directory.put(9999333919L, "AnjaliP");
		System.out.println(directory);
		System.out.println("*****Print Entries*****");
		Set<Map.Entry<Long,String>> mapset=directory.entrySet();
		Iterator<Map.Entry<Long,String>> it=mapset.iterator();
		while(it.hasNext())
		{
			Map.Entry<Long,String> entry=it.next();
			System.out.println("Key :"+entry.getKey()+
			"Name : "+entry.getValue());
		}
		System.out.println("*****Print Keys*****");
		Set<Long> kset=directory.keySet();
		Iterator<Long> itK=kset.iterator();
		while(itK.hasNext())
		{
			Long key=itK.next();
			System.out.println("    :   "+key);
		}
	
		System.out.println("*****Print Values*****");
		Collection<String> vset=directory.values();
		Iterator<String> itV=vset.iterator();
		while(itV.hasNext())
		{
			String values=itV.next();
			System.out.println("    :   "+values);
		}
	}
}
