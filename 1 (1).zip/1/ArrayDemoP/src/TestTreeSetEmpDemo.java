import java.util.TreeSet;
import java.util.Iterator;
public class TestTreeSetEmpDemo {
	public static void main(String[]args)
	{
		TreeSet<Emp> empSet=new TreeSet<Emp>();
		Emp e1=new Emp(112081, "Sania S",9000.0F);
		Emp e2=new Emp(112082, "Sneha B",1000.0F);
		Emp e3=new Emp(112084, "Vaishali K",4000.0F);
		Emp e4=new Emp(112084, "Vaishali K",4000.0F);
		
		empSet.add(e1);
		empSet.add(e2);
		empSet.add(e3);
		empSet.add(e4);
		
		Iterator<Emp> itEmp=empSet.iterator();
		while(itEmp.hasNext())
		{
			System.out.println(""+itEmp.next());
		}
	}
}
