import java.util.ArrayList;
import java.util.Iterator;
public class Product7_2
{
	public static void main(String [] args)
	{
		ArrayList<String> str=new ArrayList<String>();
		String s1= new String("Pen");
		String s2= new String("Pencil");
		String s3= new String("Notebook");
		str.add(s1);
		str.add(s2);
		str.add(s3);
		str.sort(null);
		Iterator<String> itString=str.iterator();
		while(itString.hasNext())
		{
			String values=itString.next();
			System.out.println(""+values);
	}
}
}