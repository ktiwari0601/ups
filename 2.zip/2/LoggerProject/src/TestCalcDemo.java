import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import java.util.Scanner;
public class TestCalcDemo 
{
	public static void main(String args[])
	{
		Logger myLogger=Logger.getLogger(TestCalcDemo.class);
		PropertyConfigurator.configure("log4j.properties");
		Scanner sc =new Scanner(System.in);
		myLogger.debug("This is a debug message");
		myLogger.warn("This is a warn message");
		myLogger.fatal("This is a fatal message");
		System.out.println("Enter a :");
		int a =sc.nextInt();
		myLogger.info("User entered a" +a);
		System.out.println("Enter b :");
		int b =sc.nextInt();
		sc.close();
		myLogger.info("User entered b" +b);
		int c=0;
		try
		{
			c=a/b;
			myLogger.info("c" +c);
		}
		catch(ArithmeticException ae)
		{
			ae.printStackTrace();
			myLogger.error("Divisor is zero" +ae.getMessage());
			
		}
	}
}
