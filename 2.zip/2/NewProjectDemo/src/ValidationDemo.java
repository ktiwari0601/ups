import java.util.Scanner;
import java.util.regex.Pattern;

public class ValidationDemo 
{
	@SuppressWarnings({ "unused", "resource" })
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Your Name");
		String ename = sc.next();
		StringBuilder sb = new StringBuilder();
		sb.append(ename);
		sb.reverse();
		System.out.println(sb);
		String namePattern1="[A-Z][a-z]+";
		String namePattern2="[0-9]+";
		System.out.println("You Have entered" +ename);
		if(Pattern.matches(namePattern1, ename))
		{
		System.out.println("  Valid Name");
		}
		else
		{
		System.out.println("  Invalid Name");
		}

}
}
