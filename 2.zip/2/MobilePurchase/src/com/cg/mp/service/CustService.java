package com.cg.mp.service;

import java.util.ArrayList;

import com.cg.mp.dto.Customer;
import com.cg.mp.dto.Mobile;
import com.cg.mp.exception.CustException;

public interface CustService 
{
	public int deleteMob(int mid) throws CustException;
	public ArrayList<Mobile> getAllMobile() throws CustException;
	public int addCust(Customer c) throws CustException;
	public boolean validatecusName(String name) throws CustException;
	public boolean validatePhnNo(int phnNo) throws CustException; 
	public boolean validateMailId(String mailId) throws CustException;
	public boolean validateMobileId(int MobileId) throws CustException;	
}
