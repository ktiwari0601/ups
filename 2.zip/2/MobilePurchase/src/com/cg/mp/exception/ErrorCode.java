package com.cg.mp.exception;

public class ErrorCode {

}
