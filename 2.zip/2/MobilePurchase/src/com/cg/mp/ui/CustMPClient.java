package com.cg.mp.ui;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.mp.dto.Customer;
import com.cg.mp.dto.Mobile;
import com.cg.mp.exception.CustException;
import com.cg.mp.service.CustServiceImpl;

public class CustMPClient
{
	static CustServiceImpl custservice = null;
	static Scanner sc = null;
	public static void main(String[] args) throws CustException 
	{
		int choice = 0;
		sc = new Scanner(System.in);
		custservice=new CustServiceImpl();
		System.out.println("**Welcome to MOBILE PURCHASE SYSTEM**");
		while(true)
		{
			System.out.println("What to you want to do?");
			System.out.println("\t 1:Add Cust\t 2:Show All Mobile" +"\t 3:Delete Mobile \t" +"\t 4 : Exit ");
			System.out.println("Enter your Choice");
			choice=sc.nextInt();
			
			switch(choice)
			{
			case 1 : insertCust();break;
			case 2 : dispAllmob();break;
			case 3 : delmob();break;
			default : System.exit(0);
			}
		}
	}
private static void insertCust() 
{
	try
	{
	System.out.println("Enter Pur Id");
	int purId = sc.nextInt();
	
	System.out.println("Enter Customer Name");
	String cusName = sc.next();
	if(custservice.validatecustName(cusName))
	{
		System.out.println("Enter Mail ID");
		String mailId=sc.next();
		if(custservice.validateMailId(mailId))
		{
			System.out.println("Enter Phone No.");
			String phnNo = sc.next();
			if(custservice.validatePhnNo(phnNo))
			{		
				System.out.println("Enter Pur Date");
				String purDate = sc.next();
				System.out.println("Enter Mobile Id");
				int mobileId = sc.nextInt();
				if(custservice.validateMobileId(mobileId))
				{
					Customer c= new Customer(purId,cusName,mailId,phnNo,purDate,mobileId);
					int dataInserted=custservice.addCust(c);
					if(dataInserted==1)
					{
						dispAllmob();
					}
					else
					{
						System.out.println("Sorry data is" +"not inserted");
					}	
				}
				else
				{
					throw new CustException("Invalid Data");
				}  
			}
			else
			{
				throw new CustException("Invalid Data");
			}  
		}
		else
		{
			throw new CustException("Invalid Data");
		}  
	}
				else
				{
					throw new CustException("Invalid Data");
				}  
			}    
			
		catch(CustException e) 
		{
			System.out.println(e);
			//e.printStackTrace();
		}
	}
	private static void dispAllmob() throws CustException 
	{
		ArrayList<Mobile> mobList;
		try
		{
		mobList = custservice.getAllMobile();
		System.out.println(" \tMOBID \tNAME \tPRICE \tQUANTITY");
		for(Mobile m:mobList)
		{
			System.out.println("\t"+m.getMobId()+"\t"+m.getName() + "\t" +m.getName() +"\t"+m.getQuantity());
		}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}	

	
	private static void delmob()
	{
		
		int id,data;
		try 
		{
			System.out.println("Enter id");
			id=sc.nextInt();
			data=custservice.deleteMob(id);
			if(data==1)
				System.out.println("Deleted");
			else
				throw new CustException("Not deleted");
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			System.out.println(e);
		} 
	
	
	}
}

