package com.cg.mp.dto;

import java.util.ArrayList;

public class Mobile {
	private int mobId;
	@Override
	public String toString() {
		return "Mobile [mobId=" +mobId + ", Name=" + name
				+ ", price=" + price + ", quantity=" + quantity +"]";
	}
	private String quantity;
	private String name;
	private float price;
	public int getMobId() {
		return mobId;
	}
	public void setMobId(int mobId) {
		this.mobId = mobId;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public Mobile() {
		super();
	}
	public Mobile(int mobId, String name, float price,String quantity) {
		super();
		this.mobId = mobId;
		this.name = name;
		this.price = price;
		this.quantity = quantity;
	}
	public static ArrayList<Mobile> getAllMob() {
		return Mobile.getAllMob();
	}
}
