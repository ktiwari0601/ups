package com.cg.eis.bean;
public class Employee 
{
	int Id;
	String Name;
	long Salary;
	String Designation;
	String InsuranceScheme;
	public Employee()
	{ }
	public Employee(int Id,String Name,long Salary,String Designation)
	{
		this.Id=Id;
		this.Name=Name;
		this.Salary=Salary;
		this.Designation=Designation;
	}
	
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public long getSalary() {
		return Salary;
	}
	public void setSalary(long salary) {
		Salary = salary;
	}
	public String getDesignation() {
		return Designation;
	}
	public void setDesignation(String designation) {
		Designation = designation;
	}		
}

