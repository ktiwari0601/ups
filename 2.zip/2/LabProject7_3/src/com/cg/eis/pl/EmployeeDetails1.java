package com.cg.eis.pl;
import java.util.Scanner;
public class EmployeeDetails1
{
	@SuppressWarnings({"resource" })
	public static void main(String []args)
	{
	int Id;
	String Name;
	long Salary;
	String Designation;
	String InsuranceScheme;
	
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter Id : ");
	Id = sc.nextInt();
	System.out.println("EnterName : ");
	Name = sc.next();
	System.out.println("Enter Salary : ");
	Salary = sc.nextInt();
	System.out.println("Enter Designation : ");
	Designation = sc.next();
	
		if(Designation.equals("Associate")&& (Salary>10000 && Salary<=20000))
		{
			InsuranceScheme="C";
		}
		else if(Designation.equals("Programmer")&& (Salary>20000 && Salary<=40000))
		{
			InsuranceScheme="B";
		}
		else if(Designation.equals("Manager")&& (Salary>=40000))
		{
			InsuranceScheme="A";
		}
		else
		{
			InsuranceScheme="No Scheme";
		}

		System.out.println("Id" +":" +Id +"  Name" +":" +Name +"  Salary" +":" +Salary 
				+"  Designation" +":" +Designation +"  Insurance Scheme " +":" +InsuranceScheme);
	}
}
	