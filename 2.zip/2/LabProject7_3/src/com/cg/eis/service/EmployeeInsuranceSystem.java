package com.cg.eis.service;
public class EmployeeInsuranceSystem {

}
