public class ValidateAge6_2 
{
	Person accHolder;
	private long accNum;
	private double balance;
	ValidateAge6_2()
	{ }
	ValidateAge6_2(long a,double b,Person p)
	{
		this.setAccNum(a);
		this.setBalance(b);
		accHolder=new Person();
		accHolder.name=p.name;
		try
		{
			if(p.age<18)
			{
				throw new MyException();
			}
			accHolder.age=p.age;
		}
		catch(MyException e)
		{
			System.out.println(e);
		}
	}
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
}
