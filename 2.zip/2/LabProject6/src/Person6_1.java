import java.rmi.MarshalException;
import java.util.Scanner;
public class Person6_1 
{
	public static void main(String args[]) throws Exception
	{
			@SuppressWarnings("unused")
			String a,b = null;
			@SuppressWarnings("resource")
			Scanner sc=new Scanner(System.in);
			try
			{
				System.out.println("Enter fN");
				a=sc.nextLine();
				if(a.equals(""))
					throw new Exception();
				@SuppressWarnings("unused")
				Person6_1 p = new Person6_1();
			}
			catch(MarshalException e)
			{
				System.out.println("Exception:" +e);
			}
	}
}
