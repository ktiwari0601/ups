package com.cg.mp.service;
import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.mp.dao.CustDaoImpl;
import com.cg.mp.dto.Customer;
import com.cg.mp.dto.Mobile;
import com.cg.mp.exception.CustException;

 public class CustServiceImpl implements CustService {
	CustDaoImpl custDao=null;
	public CustServiceImpl()
	{
		custDao=new CustDaoImpl();
	}
	@Override
	public ArrayList<Mobile> getAllMobile() throws CustException 
	{
		return custDao.getAllMobile();
	}
	@Override
	public int addCust(Customer c) throws CustException
	{
		return custDao.addCust(c);
	}
	@Override
	public int deleteMob(int mid) throws CustException
	{
		return custDao.deleteMob(mid);
	}
	public ArrayList<Mobile> searchMob(float lowprice, float highprice) throws CustException 
	{
		return custDao.searchMob(lowprice, highprice);
	}
	public boolean validatecustName(String cusName) throws CustException 
	{
		String namePattern="[A-Z][a-z]+";
		if(Pattern.matches(namePattern, cusName))
		{
			return true;
		}
		else
		{
			throw new CustException("Invalid : Name Should Start with capital" +"Only characters allowed");
		}
	}
	public boolean validateMailId(String mailId) throws CustException 
	{
		String mailIdPattern="[a-z]+[0-9]+@[a-z]+.[a-z]+";
		if(Pattern.matches(mailIdPattern, mailId))
		{
			return true;
		}
		else
		{
			throw new CustException("Invalid : Email id");
		}
	}
	public boolean validatePhnNo(String phnNo) throws CustException 
	{
		String phnNoPattern="[1-9][0-9]{9}";
		if(Pattern.matches(phnNoPattern, phnNo))
		{
			return true;
		}
		else
		{
			throw new CustException("Invalid :Phone number ");
		}
	}
	public boolean validateMobileId(int MobileId) throws CustException 
	{
		String mid=Integer.toString(MobileId);
		String MobileIdPattern="[0-9][0-9][0-9][0-9]";
		if(Pattern.matches(MobileIdPattern, mid))
		{
			return true;
		}
		else
		{
			throw new CustException("Invalid :Mobile Id ");
		}
	}
	@Override
	public boolean validatecusName(String name) throws CustException {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public boolean validatePhnNo(int phnNo) throws CustException {
		// TODO Auto-generated method stub
		return false;
	}
	
	
}
