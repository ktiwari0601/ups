
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class As10_1Main {
public static void main(String[] args) throws IOException
{
	FileOutputStream fos=null;
	Properties EmpPro=null;
	
	try {
		fos=new FileOutputStream("EmpPro.properties");
		EmpPro=new Properties();
		EmpPro.setProperty("Emp_Name","ABC");
		EmpPro.setProperty("Emp_Id","123");
		EmpPro.setProperty("Emp_Salary","5000");
		EmpPro.store(fos,"This is Data Base Information");
		System.out.println("Data is written in  the file");
	 	
	} catch (IOException e) {
		
		e.printStackTrace();
	}
	
	System.out.println("***Object Creation And Display***");
	 FileReader reader=new FileReader("EmpPro.properties");  
     
	    Properties p=new Properties();  
	    p.load(reader);  
	      
	    System.out.println(p.getProperty("Emp_Id"));
	    System.out.println(p.getProperty("Emp_Name")); 
	    System.out.println(p.getProperty("Emp_Salary"));  
	}
	
	
	
}









