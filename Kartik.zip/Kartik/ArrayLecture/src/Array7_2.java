import java.util.*;
import java.util.Collections;
import java.util.ArrayList;
public class Array7_2 
{
 public static void main(String[] args)
 {	
	ArrayList<String> names= new ArrayList<String>();
   	int num;
        String s;
   	Scanner n=new Scanner(System.in);
        System.out.println("Enter number of strings:");
        num=n.nextInt();
        System.out.println("Enter Strings:");	
        for(int i=0;i<num;i++)
	{
	     s=n.next();
         names.add(s);	
	}
    System.out.println("List before Sort:");
	System.out.println(names);
	Collections.sort(names);
	System.out.println("List after Sort:");
	System.out.println(names);
	
	
}
}
