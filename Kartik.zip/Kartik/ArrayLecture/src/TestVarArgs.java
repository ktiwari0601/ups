
public class TestVarArgs {


	public int add(int ...nums)

{
int sum=0;
for(int tempNum:nums)
{
	sum=sum+tempNum;
}
return sum;
}

public static void main(String[] args)
{
	TestVarArgs obj1=new TestVarArgs();
	System.out.println("Addition of Number"+ obj1.add(7,5));
    System.out.println("Adddition of Number:"+obj1.add(6,7,8));


}











}
