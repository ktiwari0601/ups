import java.util.Scanner;

public class TestArray {

	public static void main(String args[])
	{
		int[ ] marks=new int[3];
		marks[0]=90;
		marks[1]=89;
		marks[2]=99;
		for(int i=0;i<marks.length;i++)
			{System.out.println("marks"+" "+marks);}
		
		
	
	System.out.println("**************");
	
	int nums[]=null;
	nums=new int[3];
	
	
	System.out.println("**************");
	
	
	String names[]= {"Patani","igate","cAPG"};
	
	System.out.println("*********2d****");
	
	int A[][]=new int[3][2];

    A[0][0]=5;
    A[0][1]=7;
    A[0][2]=6;
	
	System.out.println("*****Emp Array******");
Scanner sc=new Scanner(System.in);
System.out.println("Enter the number of employee");
int empCount=sc.nextInt();
Emp emps[]=new Emp[empCount];

System.out.println("Enter Emp id:");
int empId=sc.nextInt();
System.out.println("Enter Emp name:");
String eName=sc.nextLine();
System.out.println("Enter Emp Salary:");
float eSal=sc.nextFloat();
	
emps[i]=new Emp(eId, eName, eSal);	
	}
	
	System.out.println("**************");
for(Emp tempEmp:emps)
{
	System.out.println(tempEmp);
}


}
