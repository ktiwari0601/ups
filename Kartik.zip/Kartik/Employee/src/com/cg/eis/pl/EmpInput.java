package com.cg.eis.pl;

import java.util.Scanner;

public class EmpInput {

public static void main(String[] args)
{

	Scanner in =new Scanner(System.in);
	
	System.out.println("Employee Class");
    
	System.out.println("Enter Employee Name");
    String emp_name= in.next();
	
    System.out.println("Enter Employee Salary");
    int emp_sal= in.nextInt();
	
    System.out.println("Enter Employee Designation");
    String emp_desig= in.next();
}
}
