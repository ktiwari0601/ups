package com.cg.eis.pl;
import java.util.*;
import java.io.*;
import com.cg.eis.bean.Employee;

public class EmpOutput {
	Employee e1;
	public void displayEmp()
	{   
		System.out.println("Employee Name:"+" "+e1.emp_name);
	    System.out.println("Employee Salary:"+" "+e1.emp_sal);
	    System.out.println("Employee Designation:"+" "+e1.emp_desig);
	    System.out.println("Insurance Category:"+" "+e1.insur);
	}
	public static void main(String[] args)
	{
   
	}
}
