package com.cg.eis.bean;
import java.util.Scanner;
public class Employee {
	public void att()
	{
	int emp_id[];
	String emp_name;
	int emp_sal;
	String emp_desig;
	int insur;   
	}
public static void main(String args[])
{
	
}
}