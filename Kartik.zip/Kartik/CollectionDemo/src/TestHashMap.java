
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
public class TestHashMap {
public static void main(String[] args)
{
   HashMap<Long,String> directory=new
		   HashMap<Long,String>();
   directory.put(10000000L,"KT");
   directory.put(20000000L,"sr");
   directory.put(30000000L,"LK");
   directory.put(40000000L,"MP");
   directory.put(50000000L,"SW");
   
   System.out.println(directory);
   System.out.println("**********ALL*******");
   Set<Map.Entry<Long,String>>mapSet=directory.entrySet();
   Iterator<Map.Entry<Long,String>> it=mapSet.iterator();
   
   while(it.hasNext())
   {
	   Map.Entry<Long, String> entry=it.next();
	   System.out.println("Key:"+entry.getKey()+"Name:"+entry.getValue());
    }
	
   System.out.println("**********Print Keys*******");
   Iterator<Map.Entry<Long,String>> itK=mapSet.iterator();
   
   while(itK.hasNext())
   {
	   Map.Entry<Long, String> entry=itK.next();
	   System.out.println("Key:"+entry.getKey());
    }
	
   System.out.println("**********Print Values*******");
   Iterator<Map.Entry<Long,String>> itV=mapSet.iterator();
   
   while(itV.hasNext())
   {
	   Map.Entry<Long, String> entry=itV.next();
	   System.out.println("Value:"+entry.getValue());
    }
	
	
}
{
}	
	
	
	
	
}
