
public class TestHashMap2 {

}
