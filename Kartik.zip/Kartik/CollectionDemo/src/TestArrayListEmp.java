
import java.util.ArrayList;
import java.util.Iterator;
public class TestArrayListEmp {


public static void main(String Args[]) 
{
	ArrayList<Emp> empList=new ArrayList<Emp>();
    Emp e1=new Emp(112081,"K",9000.0F);
    Emp e2=new Emp(112081,"l",9000.0F);
    Emp e3=new Emp(112081,"M",9000.0F);
    Emp e4=new Emp(112081,"N",9000.0F);


    empList.add(e1);
    empList.add(e2);
    empList.add(e3);
    empList.add(e4);
    
    Iterator<Emp> itEmp=empList.iterator();
    while(itEmp.hasNext())
{
	System.out.println(" ..."+itEmp.next());
}
    	







}




}
