import java.util.ArrayList;
import java.util.Iterator;
public class TestArrayList {
public static void main(String[] args)
{
	ArrayList intList=new ArrayList(4);
	Integer i1=new Integer(40);
	Integer i2=new Integer(10);
	Integer i3=new Integer(40);
	Integer i4=new Integer(30);
	String str4=new String("Kt");
	
	intList.add(i1);
	intList.add(i2);
	intList.add(i3);
	intList.add(i4);
	intList.add(str4);
	
	Iterator it=intList.iterator();
	while(it.hasNext())
	{
		 System.out.println("Entry"+it.next());
	}
	
	
	
	
}
	
	
}
