

public class Emp implements Comparable<Emp>
{
	
	
	int empId;
	String empName;
	float empSal;
	public Emp()
	{
		
	}
	
	
	public String toString()
	{
		return empId+" "+empName+" "+empSal;
	}
	
	
	
	public Emp(int EmpID, String empName,float empSal)
	{
		
	    this.empId= empId;
	    this.empName=empName;
		this.empSal=empSal;
				
		
	}

	@Override
	public boolean equals(Object obj)
	{
		Emp ee=(Emp) obj;
		if(this.empId==ee.empId)
		{
			return true;
		}
			
		else
		{
			return false;
		}
	}
	
	
	
	
	
	
	
	@Override
	public int compareTo(Emp ee)
	{
		if(this.empId<ee.empId)
		{
			return -1;
		}
		else
		{
			return +1;
		}
	
	
	
	}
	
	
	
	
}
