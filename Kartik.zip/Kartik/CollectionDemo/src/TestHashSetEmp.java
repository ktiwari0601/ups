//package collection;
import java.util.HashSet;
import java.util.Iterator;
public class TestHashSetEmp {
public static void main(String Args[]) 
{
	HashSet<Emp> empSet=new HashSet<Emp>();
    Emp e1=new Emp(112081,"K",7454.0F);
    Emp e2=new Emp(1120,"l",545.0F);
    Emp e3=new Emp(1125,"M",9440.0F);
    Emp e4=new Emp(11,"N",940.0F);

    empSet.add(e1);
    empSet.add(e2);
    empSet.add(e3);
    empSet.add(e4);
    
    Iterator<Emp> itEmp=empSet.iterator();
    while(itEmp.hasNext())
{
    System.out.println(" ..."+itEmp.next());
}
}}
