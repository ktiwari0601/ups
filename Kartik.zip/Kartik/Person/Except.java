import java.lang.Exception;
public class Except extends Exception{
}
	
	   public String toString(){ 
		return ("MyException Occurred: "+str1) ;
	   }

}
