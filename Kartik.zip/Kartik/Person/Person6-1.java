package kt;

public class  Person
{
	private String firstname;
	private String lastname;
    private char gender;
	
    //public Person()
    {   	
    	firstname="Kartik";
    	lastname="Tiwari";
    	gender='M';
    }
    public Person(String f, String l, char s )
    {
    	
    	 try{
    		 if(f == null && l==null){
    				throw new Except("Both Names Cannot be NULL");
    	    	}
    	  }
    	 catch(Except){
    	    System.out.println("Exception Caught") ;
    	    System.out.println(exp) ;
    	 }
    	
    	
    	
    	
    	
    	firstname=f;
    	lastname=l;
    	gender=s;
    }
public static void main(String args[])
{
	Person p=new Person();
	Person q=new Person(null, null , 'M');
	
	System.out.println(p.firstname+" "+p.lastname +" "+p.gender );
	System.out.println(q.firstname+" "+q.lastname +" "+q.gender );
}
}
