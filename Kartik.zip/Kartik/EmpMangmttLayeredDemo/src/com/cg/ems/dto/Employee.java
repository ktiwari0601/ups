package com.cg.ems.dto;

public class Employee {

	private int eid;
	private String empName;
	private int empSal;
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public int getEmpSal() {
		return empSal;
	}
	public void setEmpSal(int empSal) {
		this.empSal = empSal;
	}
	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", empName=" + empName + ", empSal=" + empSal + "]";
	}
	public Employee(int eid, String empName, int empSal) {
		super();
		this.eid = eid;
		this.empName = empName;
		this.empSal = empSal;
	}
	public Employee() {
		super();
	}
	
	
	
	
}
