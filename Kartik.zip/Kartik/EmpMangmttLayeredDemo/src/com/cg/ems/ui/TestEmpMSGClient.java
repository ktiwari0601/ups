package com.cg.ems.ui;

import java.util.ArrayList;
import java.util.Scanner;
import com.cg.ems.service.EmpServiceImpl;
import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.service.EmpService;

public class TestEmpMSGClient {

	static EmpService empService=null;
	static Scanner sc=null;
	public static void main (String[] args)
	{   sc=new Scanner(System.in);
	empService=new EmpServiceImpl();	
	System.out.println("****Welcome To EMS****");
		int choice=0;
		while(true)
		{
			System.out.println("What do you want to do:");
			System.out.println("\t1.Add Emp \t 2.Show All Emp \t 3.Update EMP \t 4.Delete Emp \t\n"+"\t 5.Exit ");
            System.out.println("Enter Choice:");
            choice = sc.nextInt();
            switch(choice)
            {
            case 1: insertEmp(); break;
            case 2: dispAllemp(); break;
          
            default:System.exit(1);
            }
		}
	}
		private static void insertEmp()
		{   Scanner sc=new Scanner(System.in);
		try {
			int	esalary=0;
			System.out.println("Enter ur Emp ID:");
				int eId=sc.nextInt();
				System.out.println("Enter Name:");
				String enm=sc.next();
  
				  if(empService.validateEmpName(enm))
				{
					System.out.println("Enter Salary");
					esalary=sc.nextInt();
					Employee e1=new Employee(eId, enm,esalary);
					int dataInserted= empService.addEmp(e1);
				
			         if(dataInserted==1)
					{
						dispAllemp();
					}
					 else 
					{
						System.out.println("Sorry data is not inserted");
					}
				}
		} catch (EmployeeException e) {
 			e.printStackTrace();
		}
		}
	private static void dispAllemp()
	{
		ArrayList <Employee> empList;
		
		try {
			empList = empService.getAllEmp();
			System.out.println(" \tEmpID \tEmpName \tEmpSal");
		    for(Employee ee:empList)
		    {
		    	System.out.println("\t"+ee.getEid()+"\t"+ee.getEmpName()+"\t"+ee.getEmpSal());
		    }
		
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
}
