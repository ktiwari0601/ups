package com.cg.ems.dao;
import java.io.IOException;
import com.cg.ems.util.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Logger;

import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.util.DBUtil;
import oracle.net.aso.e;

public class EmpDaoImpl implements EmpDao{
	
	//Logger daoLogger=null;
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	int data=0;
	ArrayList <Employee> empList=null;
	public EmpDaoImpl()
	{
	 	
	}
	@Override
	public ArrayList<Employee> getAllEmp() throws EmployeeException
	{
		try 
		{
			empList=new ArrayList<Employee>();
			con=DBUtil.getConn();
			String selectQry="SELECT * FROM emp_157525";
		    st=con.createStatement();
		    rs=st.executeQuery(selectQry);
		    while(rs.next())
		    { 
		   	  	empList.add(new Employee (rs.getInt("emp_id"),rs.getString("emp_name"),rs.getInt("emp_sal")));
		    }
		}
	    catch(Exception e)
		{
	    	throw new EmployeeException(e.getMessage());
		}
	    finally
	    {
	    	try
	    	{
	    		rs.close();
	    		con.close();
	    	}
	       catch(SQLException e)
	       {
	    	   //daoLogger.error(e.getMessage());
	    	   throw new EmployeeException(e.getMessage());
	       }
	    
	    }
	   //daoLogger.info("All Data Retrieved :"+empList); 
	return empList;	
	}
@Override
	public int addEmp(Employee ee) throws EmployeeException
{
	try {
		con=DBUtil.getConn();
		String insertQry="INSERT INTO emp_157525 VALUES(?,?,?)";
		pst=con.prepareStatement(insertQry);
		pst.setInt(1, ee.getEid());
		pst.setString(2, ee.getEmpName());
		pst.setInt(3, (int) ee.getEmpSal());
	    data=pst.executeUpdate();
	}
    catch (SQLException |IOException e){
    	e.printStackTrace();
    	
    	
    }
	return data;
 }
}

