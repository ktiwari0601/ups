package com.cg.ems.exception;

public class EmployeeException extends Exception {
 	 /**
	 * 
	 */
	    private static final long serialVersionUID = 1L;
	    String msg;
 	    static ErrorCode code;
        public EmployeeException(String msg)
        {
		 super(msg);
		}
        public void display()
        {
	     System.out.println("Exception Occured");
        }
        @Override
         public String toString() {
	     return "EmployeeException [getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
			+ super.toString() + "]";
	
}	
}

