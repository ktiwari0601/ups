import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
public class TestFileReadDemo {

	public static void main(String[] args)
	{
		File myFile= new File("D://Kartik//FileIO//src//TestEmpReadDemo.java");
	    //FileInputStream fis=new File();
	    FileInputStream fis=null;
	    try
	    {
	    	fis =new FileInputStream(myFile);
	    	int data=fis.read();
	    	while(data!=-1)
	    		{
	    		 System.out.println(data);
	    		 data=fis.read();
	    			    			    		
	    		}
	    		
	    }
	catch(IOException e)
	{
		
	}
	
	
	}
	
	
	
}
