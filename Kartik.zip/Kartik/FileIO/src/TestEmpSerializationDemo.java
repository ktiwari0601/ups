import java.util.Scanner;
import java.io.*;
public class TestEmpSerializationDemo {
	
	
public static void main(String[] args)
{
	

	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Emp Id:");
	int eid=sc.nextInt();
	System.out.println("Enter Emp Name:");
	String enm=sc.next();
    System.out.println("Enter Emp Salary:");
    float esl=sc.nextFloat();
     
    Employee e1=new Employee(eid, enm,esl);
    FileOutputStream fos=null;
    ObjectOutputStream oos=null;
    
    try
    {
    fos=new FileOutputStream("EmpObjs.obj");
    oos=new ObjectOutputStream(fos);
    oos.writeObject(e1);
    System.out.println("Emp e1 is witten in the file");
    }
    catch(IOException e)
    {
    	e.printStackTrace();
    }
    
    
}}
