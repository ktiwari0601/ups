

import java.io.*;
public class StringReverser
{
  public static void main(String[] args)
  {
	    File myFile=new File("D://Kartik//FileIO//Sample.txt");
		FileReader fr=null;
		FileWriter fw=null;
		BufferedReader br=null;
		BufferedWriter bw=null;
    
		try {
			fr=new FileReader(myFile);
			br=new BufferedReader(fr);
			String line=br.readLine();
			System.out.println(line);
			char rev[]=line.toCharArray();
			char rev1[]=new char[line.length()];
			
			for(int i=0;i<line.length();i++)
			{
				rev1[line.length()-i-1]=rev[i];
			}			
		   fw=new FileWriter("Sample.txt");
		   bw=new BufferedWriter(fw);
		   bw.write(rev1, 0, line.length());
		   bw.flush();
           		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
  }
}
