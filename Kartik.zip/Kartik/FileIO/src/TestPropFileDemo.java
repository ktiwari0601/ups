import java.io.*;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;

public class TestPropFileDemo {
public static void main(String args[])
{

///////////////////////////////////////////////////////////////////
	File myFile=open ("D://Kartik//FileIO/src//TestEmpReadDemo.java");
	FileReader fr=null;
	FileWriter fw=null;
	BufferedReader br=null;
	BufferedWriter bw=null;
	
		try {
			fr=new FileReader(myFile);
			br=new BufferedReader(fr);
			fw=new FileWriter("MyFile.txt");
			bw=new BufferedWriter(fw);
			String line=br.readLine();
			while(line!=null)
			{
				System.out.println(line);
				bw.write(line);
				bw.flush();
				line=br.readLine();
				
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    System.out.println("All Data Written in File");
	}
		private static File open(String string) {
		return null;}
	
}
		

