
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.FileWriter;
public class TestFileWriteDemo {

	
	public static void main(String args[])
	{
		File myFile=new File("D:/Kartik/FileIO/src/TestEmpReadDemo.java");
		FileReader fr=null;
		FileWriter fw=null;
		BufferedReader br=null;
		BufferedWriter bw=null;
		try
		{
			fr=new FileReader(myFile);
			br=new BufferedReader(fr);
			fw=new FileWriter("MyFile.txt");
			bw=new BufferedWriter(fw);
			String line=br.readLine();
			while(line!=null)
			{
				System.out.println(line);
				bw.write(line);
				bw.flush();
				line=br.readLine();
				
			}
		    System.out.println("All Data Written in File");
		}
		
		
			catch(IOException e)
			{
				e.printStackTrace();
			}
		}
	}
	
	
