
public class MaxwithLambda {

	public static void main(String[] args)
	{
		MaxFinder mf=(a,b)->(a>b)?a:b;
		System.out.println("Greatest Number Is : "+);
	}
	
}
