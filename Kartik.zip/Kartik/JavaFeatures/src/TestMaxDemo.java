
public class TestMaxDemo {
public static void main(String[] args)
{
	MaxFinder mf=new MaxFinderImpl();
	System.out.println("Greatest Number is: "+ mf.max(56, 67));
}
	
}
