import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class TestEmpSelectDemo {

	public static void main(String[] args)
	{  
		Statement st=null;
		ResultSet rs=null;
		Connection con=null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		    con=DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11g","lab1btrg22","lab1boracle");
	        st = con.createStatement();
	        rs=st.executeQuery("SELECT * FROM emp_157525");		
		    while(rs.next())
		    {
		    System.out.println(" : "+rs.getInt("emp_id")+" : "+rs.getString("emp_name")+" "+rs.getInt("salary"));
		    }
		    System.out.println("*****Result Set Metadata*****");
		    ResultSetMetaData rsmd=rs.getMetaData();
		    int colCount=rsmd.getColumnCount();
		    System.out.println("No. Of Column: "+colCount);
		    for(int i=1;i<=colCount;i++)
		    {
		    	System.out.println("Column Name: "+ rsmd.getColumnName(i)+" Column Data Type: "+rsmd.getColumnTypeName(i));
		    }
		    
		    
		}
		
		catch (ClassNotFoundException e) {
					e.printStackTrace();
		} 
		catch(SQLException e)
		{	
		e.printStackTrace();
		}
	}
	
	
	
	
	
	
	
	
	
}
