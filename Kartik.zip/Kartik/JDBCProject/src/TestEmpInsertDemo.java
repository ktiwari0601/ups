import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class TestEmpInsertDemo {
	public static void main(String[] args)
	{
	
	Scanner s=new Scanner(System.in);
	System.out.println("Enter Emp ID:");
	int empId=s.nextInt();
	System.out.println("Enter Emp name:");
	String empName=s.next();
	System.out.println("Enter Emp Salary:");
	int empSal=s.nextInt();
	Connection con=null;
	String insertQry="insert into emp_157525 VALUES (?,?,?)";
	PreparedStatement pst=null;
	s.close();
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con=DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11g","lab1btrg22","lab1boracle");
	    pst=con.prepareStatement(insertQry);
	    pst.setInt(1, empId);
	    pst.setString(2, empName);
	    pst.setInt(3, empSal);
	    
	    int noOfRecAffected=pst.executeUpdate();
	    System.out.println(noOfRecAffected + "recoed is Inserted in the Table");
	}
    catch(ClassNotFoundException|SQLException ee)
	{
    	ee.printStackTrace();
	}
}
}
