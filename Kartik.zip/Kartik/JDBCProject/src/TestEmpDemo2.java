import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class TestEmpDemo2 {

	public static void main(String[] args)
	{  
		PreparedStatement pst=null;
		Statement st=null;
		ResultSet rs=null;
		Connection con=null;
		Scanner sc=new Scanner (System.in);
		System.out.println("Enter minimum salary:");
		int minSal=sc.nextInt();
		System.out.println("Enter max sal:");
		int maxSal=sc.nextInt();
		String qry="SELECT * FROM emp_157525 where emp_sal>10?"+" emp_sal >=? and emp_sal<=?";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		    con=DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11g","lab1btrg22","lab1boracle");
	        pst = con.prepareStatement(qry);
	        pst.setInt(1, minSal);
	        pst.setInt(2, maxSal);
	        rs=pst.executeQuery("SELECT * FROM emp_157525");		
		    while(rs.next())
		    {
		    System.out.println(" : "+rs.getInt("emp_id")+" : "+rs.getString("emp_name")+" "+rs.getInt("salary"));
		    }
		}
		
		catch (ClassNotFoundException e) {
					e.printStackTrace();
		} 
		catch(SQLException e)
		{	
		e.printStackTrace();
		}
	}
	
	
	
	
	
	
	
	
	
}
