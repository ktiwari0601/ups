package com.cg.util;
import java.sql.*;
public class DBUtil {

}
