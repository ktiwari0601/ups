package com.cg.mps.util;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBUtil {

	static String driver=null;
	static String url=null;
	static String unm=null;
	static String pwd=null;
	@SuppressWarnings("unused")
	public static Connection getConn() throws IOException, SQLException
	{
		Properties myprops=loadDBInfo();
		driver=myprops.getProperty("dbDriver");
		url=myprops.getProperty("dbUrl");
		unm=myprops.getProperty("unm");
		pwd=myprops.getProperty("pwd");
	    Connection con=null;
		if (con==null)
			{
			      con=DriverManager.getConnection(url,unm,pwd);
			      System.out.println("In DB Util Con Is: "+con);
			      return con;
	 			}
		else {
            System.out.println("In Db Util else Con is: "+con);
			return con;
		}
	}
	public static  Properties loadDBInfo() throws IOException
	{
		FileReader fr=new FileReader("dbInfo.properties");
	    Properties dbProps=new Properties();
	    dbProps.load(fr);
	    return dbProps;
	
	}
	
}
