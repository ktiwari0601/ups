package com.cg.mps.ui;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Scanner;
import com.cg.mps.dto.Customer;
import com.cg.mps.dto.Mobile;
import com.cg.mps.exception.CustomerException;
import com.cg.mps.service.MobService;
import com.cg.mps.service.MobServiceImpl;

public class TestMobMSGClient 
{
    static MobService mobService =null;
    static Scanner sc=null;
    
    public static void main (String[] args)
	{   sc=new Scanner(System.in);
	mobService=new MobServiceImpl();	
	System.out.println("****Welcome To Mobile Shop****");
		int choice=0;
		while(true)
		{
			System.out.println("What do you want to do:");
			System.out.println("\t1.Add Customer \t 2.Show Inventory +\t\n"+ "3.Exit ");
            System.out.println("Enter Choice:");
            choice = sc.nextInt();
            switch(choice)
            {
            case 1: insertCust(); break;
            case 2: dispAllMob(); break;
          
            default:System.exit(1);
            }
		}
	}
     private static void insertCust()
	{   @SuppressWarnings("resource")
	Scanner sc=new Scanner(System.in);
	try {
		int pid=0;
		String cphone, cemail;
		Timestamp pdate;
		String cnm;
		int mID;
		System.out.println("Enter Customer ID:");
			pid=sc.nextInt();
			System.out.println("Enter Name:");
			cnm=sc.next();
            System.out.println("Enter Phone No.:");
            cphone=sc.next();
            System.out.println("Enter Mobile ID:");
            mID=sc.nextInt();
            pdate=new Timestamp(new java.util.Date().getTime());
			  if(MobService.validateCustName(cnm))
			{
				System.out.println("Enter Email");
				cemail=sc.next();
				Customer c1=new Customer(pid, cnm, cemail,cphone,pdate,mID);
				int dataInserted= MobService.addCust(c1);
			
		         if(dataInserted==1)
				{
					dispAllMob();
				}
				 else 
				{
					System.out.println("Sorry data is not inserted");
				}
			}
			  else
			  {
				  System.out.println("Sorry data is not inserted");
			  }
					  
	}
	catch(CustomerException e) {
			e.printStackTrace();
	}
	}
private static void dispAllMob()
{
	ArrayList <Mobile> MobList;
	
	try {
		MobList = MobService.getMobDet();
		System.out.println(" \tMobile_ID \tMobile_Name \tMobile_Price \tQuantity");
	    for(Mobile mm:MobList)
	    {
	    	System.out.println("\t"+mm.getMid()+"\t"+mm.getmName()+"\t"+mm.getPrice()+"\t"+mm.getMquant());
	    }
	
	} catch (Exception e) {
		e.printStackTrace();
	}
	
}
   
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

