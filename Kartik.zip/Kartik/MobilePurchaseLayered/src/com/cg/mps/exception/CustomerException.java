package com.cg.mps.exception;

public class CustomerException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	String msg;
	static ErrorCode code;
	public CustomerException(String msg)
	{
		super(msg);
	}
	public void display()
	{
		System.out.println("Customer Exception Occured");
	}
	
}
