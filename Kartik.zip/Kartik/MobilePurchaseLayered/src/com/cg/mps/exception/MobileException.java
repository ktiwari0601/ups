package com.cg.mps.exception;

public class MobileException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
    String msg;
    static ErrorCode code;
    public MobileException(String msg)
    {
    	super(msg);
    }
    public void display()
    {
    	System.out.println("Exception Occured");
    }

}
