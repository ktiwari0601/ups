package com.cg.mps.service;

import java.util.ArrayList;
import java.util.regex.Pattern;
import com.cg.mps.dao.MobDaoImpl;
import com.cg.mps.dto.Customer;
import com.cg.mps.dto.Mobile;
import com.cg.mps.exception.CustomerException;
import com.cg.mps.exception.MobileException;

public class MobServiceImpl implements MobService
{
	MobDaoImpl MobDao=null;
	public MobServiceImpl()
	{
		MobDao=new MobDaoImpl();
	}

	public int addCust(Customer cc) throws CustomerException {
		
		
		return MobDao.addCust(cc);
	}

	public ArrayList<Mobile> getMobDet() throws MobileException {
		// TODO Auto-generated method stub
		return MobDao.getMobDet();
	}
	public boolean validateCustName(String cName) throws CustomerException
	  {
		  String namePattern="[A-Z][a-z]+";
		  if(Pattern.matches(namePattern, cName))
		  {
			  return true;
		  }
		  else
		  {
			  throw new CustomerException("Invalid Empl Name. Should start with capital "+" Only characters required");
		  
		  }
	  }

	
	

}
