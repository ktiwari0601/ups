
package com.cg.mps.service;

import java.util.ArrayList;

import com.cg.mps.dao.MobDao;
import com.cg.mps.dto.Customer;
import com.cg.mps.dto.Mobile;
import com.cg.mps.exception.CustomerException;
import com.cg.mps.exception.MobileException;

public interface MobService 
{
	public static int addCust(Customer cc) throws CustomerException {
		// TODO Auto-generated method stub
		return MobDao.addCust();
	}
	public static ArrayList<Mobile> getMobDet() throws MobileException {
		// TODO Auto-generated method stub
		return MobDao.getMobDet();
	}
	public static boolean validateCustName(String eName) throws CustomerException {
		// TODO Auto-generated method stub
		return false;
	}
}
