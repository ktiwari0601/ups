package com.cg.mps.dto;

public class Mobile {
private int mid;
private String mName;
private int price;
private String mquant;
public int getMid() {
	return mid;
}
public void setMid(int mid) {
	this.mid = mid;
}
public String getmName() {
	return mName;
}
public void setmName(String mName) {
	this.mName = mName;
}
public int getPrice() {
	return price;
}
public void setPrice(int price) {
	this.price = price;
}


public String getMquant() {
	return mquant;
}
public void setMquant(String mquant) {
	this.mquant = mquant;
}
public Mobile() {
	super();
}
public Mobile(int mid, String mName, int price, String mquant) {
	super();
	this.mid = mid;
	this.mName = mName;
	this.price = price;
	this.mquant = mquant;
}
@Override
public String toString() {
	return "Mobile [mid=" + mid + ", mName=" + mName + ", price=" + price + ", mquant=" + mquant + "]";
}


}
