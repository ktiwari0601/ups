package com.cg.mps.dto;

import java.sql.Timestamp;

public class Customer
{
	private int pucId;
	private String cName;
	private String cEmail;
	private String cPhn;
    private Timestamp pDate;
	private int mid ;
	public int getPucId() {
		return pucId;
	}
	public void setPucId(int pucId) {
		this.pucId = pucId;
	}
	public String getcName() {
		return cName;
	}
	public void setcName(String cName) {
		this.cName = cName;
	}
	public String getcEmail() {
		return cEmail;
	}
	public void setcEmail(String cEmail) {
		this.cEmail = cEmail;
	}
	public String getcPhn() {
		return cPhn;
	}
	public void setcPhn(String cPhn) {
		this.cPhn = cPhn;
	}
	public Timestamp getpDate() {
		return pDate;
	}
	public void setpDate(Timestamp pDate) {
		this.pDate = pDate;
	}
	public int getMid() {
		return mid;
	}
	public void setMid(int mid) {
		this.mid = mid;
	}
	public Customer(int pucId, String cName, String cEmail, String cPhn, Timestamp pDate, int mid) {
		super();
		this.pucId = pucId;
		this.cName = cName;
		this.cEmail = cEmail;
		this.cPhn = cPhn;
		this.pDate = pDate;
		this.mid = mid;
	}
	public Customer() {
		super();
	}
	}
