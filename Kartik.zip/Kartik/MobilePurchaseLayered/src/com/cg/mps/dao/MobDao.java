package com.cg.mps.dao;

import java.util.ArrayList;
import com.cg.mps.dto.Mobile;

import com.cg.mps.exception.MobileException;

public interface MobDao {

	
	public static ArrayList<Mobile> getMobDet() throws MobileException {
		// TODO Auto-generated method stub
		return MobDao.getMobDet();
	}
	public static int addCust() {
		// TODO Auto-generated method stub
		return MobDao.addCust();
	}
	
}
