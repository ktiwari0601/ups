package com.cg.mps.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import com.cg.mps.dto.Customer;
import com.cg.mps.dto.Mobile;
import com.cg.mps.exception.CustomerException;
import com.cg.mps.exception.MobileException;
import com.cg.mps.util.DBUtil;

public class MobDaoImpl implements MobDao{

	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	int data=0;
	ArrayList <Mobile> mobList=null;
	public MobDaoImpl() {
		super();
	}
	
	public int addCust(Customer cc) throws CustomerException 
	{
	   try {
		con=DBUtil.getConn();
		String insertQry="INSERT INTO purchasedetails VALUES(?,?,?,?,?)";
		pst=con.prepareStatement(insertQry);
		pst.setInt(1, cc.getPucId());
		pst.setString(2, cc.getcName());
		pst.setString(3, cc.getcEmail());
		pst.setString(4, cc.getcPhn());
		pst.setTimestamp(5, cc.getpDate());
		pst.setInt(6, cc.getMid());
		data=pst.executeUpdate();
		
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	  return data; 
	   
	}

	public ArrayList<Mobile> getMobDet() throws MobileException 
	{
		try {
			mobList=new ArrayList<Mobile>();
			con=DBUtil.getConn();
			String selectQry="SELECT * FROM mobiles";
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			while(rs.next())
			{
				mobList.add(new Mobile(rs.getInt("mobileid"),rs.getString("name"),rs.getInt("price"),rs.getString("quantity")));
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return mobList;
	}

}
