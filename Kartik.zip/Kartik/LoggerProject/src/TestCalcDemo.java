import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import java.util.Scanner;
public class TestCalcDemo {

	public static void main(String args[])
	{
	    Logger myLogger=Logger.getLogger(TestCalcDemo.class);
		PropertyConfigurator.configure("log4j.properties");
		Scanner sc=new Scanner(System.in);
		myLogger.debug("This is debug message");
		myLogger.warn("This is warn message");
		myLogger.fatal("This is fatal message");
		System.out.println("Enter a: ");
		int a=sc.nextInt();
		myLogger.info("User entered a: " +a);
		System.out.println("Enter b: ");
		int b=sc.nextInt();
		myLogger.info("User entered b: " +a);
		int c=0;
		try {
			c=a/b;
			System.out.println("Output: "+c);
		    myLogger.info("c: "+c);
		}
		catch(ArithmeticException e)
		{
			e.printStackTrace();
			myLogger.info("Divisor is zero!!!");
		}
	}
	
}
