import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class CalculatorTest {
static Calculator calc=null;
@BeforeClass
public static void setUp()
{
	calc = new Calculator();
	System.out.println("Setup is call once"+" Before the execution of "+ "all test cases.");
	
}

@AfterClass
public static void tearDown()
{
	System.out.println("tearDown is call once"+" after the execution of "+ "all test cases.");
}

@Before
public void init()

{
	System.out.println("init is call once "+"Before the execution of "+"all test cases");
}
@After
public void destroy()
{
	System.out.println("destroy is call once "+"After the execution of "+"all test cases");
}
@Test
public void testDivide1()
{
	Assert.assertEquals(5, calc.divide(20));
}
@Test
public void testDivide2()
{
	Assert.assertEquals(10, calc.divide(10));
}
@Test(expected=ArithmeticException.class)
public void testDivide3()
{
	Assert.assertEquals(10, calc.divide(0));
}

}
